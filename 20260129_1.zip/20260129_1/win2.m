function varargout = win2(varargin)
% WIN2 MATLAB code for win2.fig
%      WIN2, by itself, creates a new WIN2 or raises the existing
%      singleton*.
%
%      AXES_TWO = WIN2 returns the handle to a new WIN2 or the handle to
%      the existing singleton*.
%
%      WIN2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WIN2.M with the given input arguments.
%
%      WIN2('Property','Value',...) creates a new WIN2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before win2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to win2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only two
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help win2

% Last Modified by GUIDE v2.5 09-Jun-2021 12:10:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @win2_OpeningFcn, ...
                   'gui_OutputFcn',  @win2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before win2 is made visible.
function win2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to win2 (see VARARGIN)

% Choose default command line output for win2
handles.output = hObject;

handles.min_range_two.Value=0;
handles.min_range_two.String=num2str(handles.min_range_two.Value);

handles.max_range_two.Value=2048;
handles.max_range_two.String=num2str(handles.max_range_two.Value);


axes(handles.axes_two)
handles.two=imagesc(1:1440,...
    1:1440,...
    zeros(1440,1440),...
    'Parent',handles.axes_two);
caxis([0 2048]);colorbar;colormap('jet');axis off;axis equal
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes win2 wait for user response (see UIRESUME)
% uiwait(handles.win2);





function max_range_two_Callback(hObject, eventdata, handles)
handles.max_range_two.Value=str2double(handles.max_range_two.String);

handles=two_axe(handles);
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = win2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function min_range_two_Callback(hObject, eventdata, handles)
handles.min_range_two.Value=str2double(handles.min_range_two.String);

handles=two_axe(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function min_range_two_CreateFcn(hObject, eventdata, handles)
% hObject    handle to min_range_two (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function max_range_two_CreateFcn(hObject, eventdata, handles)
% hObject    handle to max_range_two (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in auto_contrast_two.
function auto_contrast_two_Callback(hObject, eventdata, handles)
a=get(handles.two,'CData');
MIN=min(min(a));
MAX=max(max(a));

handles.min_range_two.Value=MIN;
handles.min_range_two.String=num2str(handles.min_range_two.Value);

handles.max_range_two.Value=MAX;
handles.max_range_two.String=num2str(handles.max_range_two.Value);



handles=two_axe(handles);
guidata(hObject, handles);
