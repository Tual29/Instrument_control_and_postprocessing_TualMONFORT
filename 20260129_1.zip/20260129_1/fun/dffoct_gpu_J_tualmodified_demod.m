function [dffoct,Ht,St,Vt,CuSt,f0t,handles] = dffoct_gpu_J_tualmodified_demod(im,handles)
tic
s = size(im);
% freq_min = round(s(3).*0.03);   % Minimum frequency to consider in Fourier domain.

% Hard coded parameters
n_std = 50;     % Number of sample in the moving STD.
freq_min = 4;   % Minimum frequency to consider in Fourier domain.

% We normalize each frame to remove sensor frame to frame instabilities.
im = single(squeeze(im));
s = size(im);

% directMean = (mean(mean(im,1),2));
directMean = (mean(im,[1 2]));


%     im=(im./directMean);
    % im=(im./directMean)-1;
% try im=(mean(directMean,3).*im./(directMean+0.0001));
im=(mean(directMean,3).*im./(directMean+0.0001));
% or simply im without normalisation


        imGPU = gpuArray(im);
        V = zeros(s(1),s(2),s(3)/16,'single','gpuArray');
        CuS = zeros(s(1),s(2),s(3)/16,'single','gpuArray');
%         whos V

        for i = 1:floor((s(3)-n_std)/16)
%             a=std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
%             whos a
            V(:,:,i) = std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
            CuS(:,:,i) = max(abs(cumsum(mean(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)-imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)),[],3);
            
        end
        V = gather(mean(V,3));
        
%         CuS = zeros(s(1),s(2),s(3)/16,'single','gpuArray');


%         for i = 1:floor((s(3)-n_std)/16)
% %             a=std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
% %             whos a
%             CuS(:,:,i) = max(abs(cumsum(mean(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)-imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)),[],3);
%             
%         end
        CuS = gather(max(CuS,[],3));
 DI = gather(mean(abs(diff(imGPU,1,3)),3));
        
        % Average 4 samples
        imMean = zeros(s(1),s(2),s(3)/4,'single','gpuArray');
        for i = 1:s(3)/4
            imMean(:,:,i) = single(mean(imGPU(:,:,(i-1)*4+1:i*4),3));
        end
        clear imGPU
        
        % Compute Fourier transform and normalize as if it were a
        % probability distribution
        data_freq = abs(fft(imMean,[],3));
        clear imMean
        
        %f0=mean(abs(data_freq(:,:,4-1:4+1)),3);%ifVmax=9 Volts
        f0=(abs(data_freq(:,:,4-0:4+0)));%ifVmax=9 Volts
        data_freq = data_freq(:,:,4+2:s(3)/8+1);
        normL1 = reshape(repmat(sum(data_freq,3),1,s(3)/8-freq_min),s(1),s(2),s(3)/8-freq_min);
        data_freq = data_freq./normL1;
        clear normL1
%        whos data_freq
        
%         qsd=linspace(0,100/4,s(3)/8-2);
%         whos qsd
%         rez=repelem(gpuArray.linspace(0,100/4,s(3)/8-2),s(1)*s(2));
%         whos rez
%         %hgf=reshape(rez);
%         whos hgf
        %g=gpuArray.linspace(0,100/4,s(3)/8-2);
        f = reshape(repelem(gpuArray.linspace(0,handles.save_oct_frame_per_second.Value/4,s(3)/8-4),s(1)*s(2)),s(1),s(2),s(3)/8-freq_min);
        %whos f % S component is computed as the probability distribution STD
        S = gather(sqrt(dot(data_freq,f.^2,3)-dot(data_freq,f,3).^2));
        data_freq = data_freq - reshape(repmat(min(data_freq,[],3),1,s(3)/8-4),s(1),s(2),s(3)/8-freq_min);
        % H component is computed as the probability distribution mean.
        H = gather(dot(data_freq,f,3));
        clear data_freq f
        
        
        
Ht=double(H);
St=double(S);
Vt=double(V);
f0t=double(f0);

% DIt=double(DI);

CuSt=double(DI);
toc
% We saturate 0.01% of V pixels and rescale it between 0 and 1
% Vf = CuSt;
% 
%     handles.exp.dffoct.Vmax = prctile(CuSt(:),99.9);
%     handles.exp.dffoct.Vmin = prctile(CuSt(:),0.1);
% 
% Vf(CuSt> handles.exp.dffoct.Vmax) =  handles.exp.dffoct.Vmax;
% Vf(CuSt< handles.exp.dffoct.Vmin) =  handles.exp.dffoct.Vmin;


Vf = CuSt;

    handles.exp.dffoct.Vmax = prctile(CuSt(:),99.9);
    handles.exp.dffoct.Vmin = prctile(CuSt(:),0.1);

Vf(CuSt> handles.exp.dffoct.Vmax) =  handles.exp.dffoct.Vmax;
Vf(CuSt< handles.exp.dffoct.Vmin) =  handles.exp.dffoct.Vmin;
Vf = rescale(Vf,0,1);

% Vf = rescale(Vf,0,1);

% We saturate 5% of S pixels and rescale it between 0 and 0.95 (if there
% are previously computed images, then the previous saturation is applyied
% in order to obtain a consistant colormap).
Sf = St;
Sf = rescale(Sf, 0, 0.95);

    handles.exp.dffoct.Smin = prctile(Sf(:),5);

    handles.exp.dffoct.Smax = prctile(Sf(:),100);


Sf(Sf>handles.exp.dffoct.Smax) = handles.exp.dffoct.Smax;
Sf(Sf<handles.exp.dffoct.Smin) = handles.exp.dffoct.Smin;
Sf = rescale(-Sf, 0, 0.95);

% We saturate 0.1% of H pixels and rescale it between 0 (red) and 0.66 (blue) (if there
% are previously computed images, then the previous saturation is applyied
% in order to obtain a consistant colormap).
Hf = imgaussfilt(rescale(Ht,0,1),4);
Hf = rescale(Hf,0,0.66);

    handles.exp.dffoct.Hmin = prctile(Hf(Vf>0.5),0.1);

    handles.exp.dffoct.Hmax = prctile(Hf(Vf>0.5),99.9);


Hf(Hf<handles.exp.dffoct.Hmin) = handles.exp.dffoct.Hmin;
Hf(Hf>handles.exp.dffoct.Hmax) = handles.exp.dffoct.Hmax;
Hf = rescale(-Hf,0,0.66);

% We construct the DFFOCT image.
dffoct_hsv(:,:,1) = (Hf);
dffoct_hsv(:,:,2) = (Sf);
dffoct_hsv(:,:,3) = (Vf);

dffoct = hsv2rgb(dffoct_hsv);
toc
end