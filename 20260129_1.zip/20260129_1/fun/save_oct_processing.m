function save_oct_processing(obj,event,handles)
global I
global T
global Z % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
global X
global Y



if I==handles.save_oct_num_of_trig.Value+1%triggers the pushbutton save to be green and knowing that there is no data logging
    if handles.save_oct_mode.Value==8 || handles.save_oct_mode.Value==14 || handles.save_oct_mode.Value==15 || handles.save_oct_mode.Value==16 || handles.save_oct_mode.Value==3 || handles.save_oct_mode.Value==4
        if (Z) == length(handles.flag)
            if handles.part==2 || handles.save_oct_mode.Value==16 || handles.save_oct_mode.Value==4 || handles.save_oct_mode.Value==3
                if Y == size(handles.moz_y,1)
                    if X == size(handles.moz_x,2)
%                 stop(handles.master.d)
%                 stop(handles.master.vid_cam_oct)
                handles.save_oct_pushbutton.BackgroundColor=[0 1 0];
                handles.save_oct_pushbutton.Value = 0;
                    end
                end
            end 
        end
    else
%         stop(handles.master.d)
%         stop(handles.master.vid_cam_oct)
        handles.save_oct_pushbutton.BackgroundColor=[0 1 0];
        handles.save_oct_pushbutton.Value = 0;
    end
end

I=I+1;
% T=T+1;


Image=squeeze(getdata(handles.master.vid_cam_oct));%16 bit image
5
if handles.save_oct_waste.Value>0 
    if handles.part==1
    Image=Image(:,:,1:end-handles.save_oct_waste.Value);
    end
end

if handles.save_oct_binning.Value>1% if binning, the information is lost when averaging with output in 16bit....
    %However, time used by gpuArray(single(uint16(X))) > single(gpuArray(uint16(X))) by a factor of 3 (roughtly)
    %need to choose between transfering the data already on the gpu or not
    %d=uint16(65000.*rand(1440,1440,100));tic;single(gpuArray(d));wait(gpuDevice);toc;tic;gpuArray(single(d(:,:,1:50)));toc
    %except for DFFOCT, this should not be critical
    %condition on mode then
    if handles.save_oct_mode.Value<6% if no dffoct
        Image=binning_data_single(Image,handles.save_oct_binning.Value);
    elseif handles.save_oct_mode.Value==16
        Image=binning_data_single(Image,handles.save_oct_binning.Value);
    else
        %if low memory gpu
%         Image=binning_data_single(Image,handles.save_oct_binning.Value);
        %otherwise
        Image=binning_data_single(Image,handles.save_oct_binning.Value);
    end
end

[s1, s2, s3]=size(Image);
dd=handles.dd;
format=handles.save_oct_format.Value;

switch handles.save_oct_mode.Value
    
    case 1
        
        if handles.save_oct_accu.Value==1          
        else           
            Image=binning_data_single(Image,handles.save_oct_accu.Value);%accu is equivalent to bin in this case
            %single outputed because mean on uint16 can lead to non-integer
            %result.
        end
           parfeval(@save_oct_parfeval, 0,Image,dd,T,format,'Raw') 
          
           if handles.save_oct_display.Value==1
               set(handles.master.gui1Handles.one,'CData',Image(:,:,1));
           end
  
    case 3
        %2-phase
        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing

        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
        if handles.part==1
            s3
            if s3>=2
                Name = ['2Phase_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                pas=2;
                tr=floor(s3/pas);

                if handles.save_oct_accu.Value==1
                    A=abs(int16(Image(:,:,1))-int16(Image(:,:,2)));
                else           
                    A=reshape((Image(:,:,1:(pas*tr))),s1*s2,pas,[]);% put that in a function
                    A=reshape(mean(abs(single(A(:,1,:))-single(A(:,2,:))),3),s1,s2);
                end
                format
                parfeval(@save_oct_parfeval, 0,A,dd,T,format,Name)

                if handles.save_oct_display.Value==1
                    set(handles.master.gui2Handles.two,'CData',squeeze(A(:,:,1)));
                end
            end%condition on frame >=2
        end
%%%%
%         Name = ['2Phase_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
%         
% 
%         if s3>=2
% 
%             pas=2;
%             tr=floor(s3/pas);
% 
%         A=abs(std(single(Image),0,3));            
%         parfeval(@save_oct_parfeval, 0,A,dd,T,format,Name) 
% 
%         end

    case 4
        %4-phase

        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing

        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
                if handles.part==1
                    if s3>=2
                        Name = ['4Phase_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                        pas=4;
                        tr=floor(s3/pas);

                        if handles.save_oct_accu.Value==1
                            A=int16(0.5*sqrt((Image(:,:,1)-Image(:,:,3)).^2+(Image(:,:,2)-Image(:,:,4)).^2));
                        else 
                            A=reshape((Image(:,:,1:(pas*tr))),s1*s2,pas,[]);% put that in a function
                            A=reshape(mean((int16(0.5*sqrt((Image(:,1,:)-Image(:,3,:)).^2+(Image(:,2,:)-Image(:,4,:)).^2))),3),s1,s2);
                        end
                        parfeval(@save_oct_parfeval, 0,A,dd,T,format,Name)

                        if handles.save_oct_display.Value==1
                            set(handles.master.gui2Handles.two,'CData',squeeze(A(:,:,1)));
                        end
                    end%condition on frame >=2
                end
        
    case 6
        
        
%         [Iampl, Ephase]=multi_phases(gpuArray(single(Image)),handles.mode_multi_phase.Value);
        [Iampl, Ephase]=multi_phases((single(Image)),3);

        set(handles.master.gui1Handles.one,'CData',single(gather(Iampl)));
        set(handles.master.gui2Handles.two,'CData',single(gather(Ephase)));
    case 7
6
fps=handles.save_oct_frame_per_second.Value;
te=handles.save_oct_expo_time.Value;
            
        if handles.save_oct_accu.Value==1
            [dffoct,Ht,St,Vt,CuSt,handles] = dffoct_gpu_J_tualmodified_save(Image,handles);
        else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,CuSt,handles] = dffoct_gpu_J_tualmodified_save(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        
        parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,dd,T,format,'DFFOCT',fps,te)

    case 8 %dffoct +2phases
%                 [value posi]=maxk(sum(abs(diff(int16(Image),1,3)),...
%             [1,2]),handles.save_oct_accu.Value,3);
        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
        
        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
            if handles.part==1
                if s3>=2
                    
                    Name = ['2Phase_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                    pas=2;
                    tr=floor(s3/pas);
            
            

                    if handles.save_oct_accu.Value==1
                        %A=abs(int16(Image(:,:,1))-int16(Image(:,:,2)));
                        A=abs(mean(single(diff(Image,1,3)),3));
                    else           
                        A=reshape((Image(:,:,1:(pas*tr))),s1*s2,pas,[]);% put that in a function
                        A=reshape(mean(abs(single(A(:,1,:))-single(A(:,2,:))),3),s1,s2);
                    end
                    parfeval(@save_oct_parfeval, 0,A,dd,T,format,Name)
                    
                    if handles.save_oct_display.Value==1
                        set(handles.master.gui2Handles.two,'CData',squeeze(A(:,:,1)));
                    end

        
                end%condition on frame >=2
            
            elseif handles.part==2
                

                Name = ['DFFOCT_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                
                fps=handles.save_oct_frame_per_second.Value;
                te=handles.save_oct_expo_time.Value;
            
        if handles.save_oct_accu.Value==1
            456
            %[dffoct,Ht,St,Vt,CuV,handles] = dffoct_gpu_J_tualmodified_test2(Image,handles);
%             [dffoct,Ht,St,Vt,CuV,handles] = dffoct_dct_gpu_J_tualmodified_test(Image,handles);
            imwrite(uint16(20.*mean(Image,3)),[dd '\' 'BrightField' name(1,7:end) 't' num2str(T) '.tif'])
            [dffoct,Ht,St,Vt,CuV,f0t,handles] = dffoct_gpu_J_tualmodified_demod(Image,handles);
%            
        else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,handles] = dffoct_gpu_J_tualmodified_test(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        parfeval(@save_oct_parfeval_hsv_demod, 0,dffoct,Ht,St,Vt,CuV,f0t,dd,T,format,Name,fps,te)
        %parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,CuV,dd,T,format,Name,fps,te)
            end
        
        
        

    case 9

        V = V_gpu(single(gpuArray(Image)));
        set(handles.gui1Handles.one,'CData',V);
        
        
    case 14
        
        
        
        
        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
        
        
        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
        
        
            if handles.part==1
                
                Name = ['DFFOCT_PS_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                
                fps=handles.save_oct_frame_per_second.Value;
                te=handles.save_oct_expo_time.Value;
            
        if handles.save_oct_accu.Value==1
            456
            [dffoct,Ht,St,Vt,CuV,handles] = dffoct_gpu_J_tualmodified_test(Image,handles);
        else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,handles] = dffoct_gpu_J_tualmodified_test(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        
        parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,CuV,dd,T,format,Name,fps,te)
            
            elseif handles.part==2
                

                Name = ['DFFOCT_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                
                fps=handles.save_oct_frame_per_second.Value;
                te=handles.save_oct_expo_time.Value;
            
        if handles.save_oct_accu.Value==1
            456
            [dffoct,Ht,St,Vt,CuV,handles] = dffoct_gpu_J_tualmodified_test(Image,handles);
        else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,handles] = dffoct_gpu_J_tualmodified_test(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        
        parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,CuV,dd,T,format,Name,fps,te)
            end

    case 15
        
        
        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
        
        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
            if handles.part==1
                if s3>=2
                    
                    Name = ['2Phase_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                    pas=2;
                    tr=floor(s3/pas);
            
            

                    if handles.save_oct_accu.Value==1
                        A=abs(int16(Image(:,:,1))-int16(Image(:,:,2)));
                    else           
                        A=reshape((Image(:,:,1:(pas*tr))),s1*s2,pas,[]);% put that in a function
                        A=reshape(mean(abs(single(A(:,1,:))-single(A(:,2,:))),3),s1,s2);
                    end
                    parfeval(@save_oct_parfeval, 0,A,dd,T,format,Name)
                    
                    if handles.save_oct_display.Value==1
                        set(handles.master.gui2Handles.two,'CData',squeeze(A(:,:,1)));
                    end

        
                end%condition on frame >=2
            
            elseif handles.part==2
                

                Name = ['DFFOCT_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                
                fps=handles.save_oct_frame_per_second.Value;
                te=handles.save_oct_expo_time.Value;
            
        if handles.save_oct_accu.Value==1
            456
            [dffoct,Ht,St,Vt,CuV,handles] = dffoct_gpu_J_tualmodified_test2(Image,handles);
        else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,handles] = dffoct_gpu_J_tualmodified_test(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        
        parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,CuV,dd,T,format,Name,fps,te)
        
            elseif handles.part==3
                
                Name = ['DFFOCT_photo_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
                
                fps=handles.save_oct_frame_per_second.Value;
                te=handles.save_oct_expo_time.Value;
                
                if handles.save_oct_accu.Value==1
            456
            [dffoct,Ht,St,Vt,CuV,handles] = dffoct_gpu_J_tualmodified_test2(Image,handles);
                else
            dffoctB=zeros(1440,1440,3);
            HtB=zeros(1440,1440);
            StB=zeros(1440,1440);
            VtB=zeros(1440,1440);
            si=handles.save_oct_frames_acquired_fct_C.Value;
                for ii=1:handles.save_oct_accu.Value
                    ii
                    [dffoct,Ht,St,Vt,handles] = dffoct_gpu_J_tualmodified_test(Image(:,:,1+(ii-1)*si:si*ii),handles);
                    dffoctB=dffoctB+dffoct;
                    HtB=HtB+Ht;
                    StB=StB+St;
                    VtB=VtB+Vt;
                end
        end
        
        parfeval(@save_oct_parfeval_hsv, 0,dffoct,Ht,St,Vt,CuV,dd,T,format,Name,fps,te)
            end
            
    case 16
        
        
        name = handles.flag;
        name = name(1,Z); % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
        
        position_x=handles.moz_x(1,X);
        position_y=handles.moz_y(1,Y);
        
        if handles.part==1         
            Name = ['Raw_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)]; 
        elseif handles.part==2
            Name = ['Raw_photo_z' num2str(name) 'x' num2str(position_x) 'y' num2str(position_y)];         
        end
        Name
        
        
     whos Image
        
        
%          fps=handles.save_oct_frame_per_second.Value;
%                 te=handles.save_oct_expo_time.Value;
%         f=parfeval(@save_oct_parfeval, 0,Image,dd,T,format,Name,fps,te)
% wait(f)
%         
        
       
       
end
