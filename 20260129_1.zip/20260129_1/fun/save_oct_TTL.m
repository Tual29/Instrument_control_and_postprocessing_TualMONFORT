function handles=save_oct_TTL(handles)

 master=get_master_handles;
 
 Ns=handles.save_oct_frame_per_second.Value*100;%number of samples per seconds; still not perfectly clear how many seconds should be preloaded

if master.checkbox_save_oct.Value==1
    
    
   

fds=zeros(100,3);       
        
        for ii=1:100
            if ii<=handles.save_oct_duty_cycle_TTL.Value
                fds(ii,1)=5;
            end
        end
        
        fds(:,2)=ones(100,1).*master.piezo_voltage_dc.Value;
        
%         fds=circshift(fds,master.phase_shift.Value);
        
whos fds
        

        
switch handles.save_oct_mode.Value
    case 1
        %raw data
        mo=1;
        if mo==1
     
            fdss=fds;

            t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
            t_b_min=5;
            ns=100-handles.save_oct_duty_cycle_TTL.Value;
            if t_p_b<t_b_min

                as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
                fdss=[fdss;zeros(as,3)];
                ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
            elseif handles.save_oct_duty_cycle_TTL.Value>50
            end

            fdss=circshift(fdss,ceil(ns/2));

            hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  

            fer=ceil(size(hgf,1)./2);

            for jj=1:2%use the initial loop for cleaner reading
                hgf(1+(jj-1)*fer:jj*fer,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);
            end   

            figure(234)
            plot(hgf(:,1))
            hold on
            plot(hgf(:,2))

            handles.TTL_output_save=repmat(hgf,[ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
            fds(:,2)=0.*ones(size(fds,1),1);%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            fds=repmat(fds, [10*3, 1]);
            handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 

            kkl=repmat(fds, [ceil(Ns./(10*3)), 1]);
            whos kkl

        elseif mo==2
%%%%%%%%%%%%%%%%%%%%%%%%%%test multiphase
            fdss=fds;
        
            t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
            t_b_min=5;
            ns=100-handles.save_oct_duty_cycle_TTL.Value;
            if t_p_b<t_b_min
                as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
                fdss=[fdss;zeros(as,3)];
                ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
            elseif handles.save_oct_duty_cycle_TTL.Value>50
            end

            fdss=circshift(fdss,ceil(ns/2));

            hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  

            fer=ceil(size(hgf,1)./2);

            for jj=1:2%use the initial loop for cleaner reading
                    hgf(1+(jj-1)*fer:jj*fer,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);
            end   
            figure(234)
            plot(hgf(:,1))
            hold on
            plot(hgf(:,2))

            handles.TTL_output_save=repmat(hgf,[ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            po=1;

            454

            if po==1
               445
               lkj=linspace(0,6,handles.save_oct_frames_acquired_fct_C.Value*handles.save_oct_binning.Value) ;  

               lkj=repelem(lkj, 1, 10^2);

               fds=repmat(fds, [handles.save_oct_frames_acquired_fct_C.Value*handles.save_oct_binning.Value, 1]);

               fds(:,2)=lkj.';

               handles.TTL_output_save_2=repmat(fds, [100, 1]);

                kkl=repmat(fds, [10, 1]);
                whos kkl
       
            elseif po==2
                fdss=fds;
                ns=100-handles.save_oct_duty_cycle_TTL.Value;
                fdss=circshift(fdss,ceil(ns/2)); 
                hgf=repmat(fdss, [2*handles.save_oct_binning.Value*handles.save_oct_frames_acquired_fct_C.Value, 1]); 
            
                Value_Vo=linspace(0,10-master.V_c_TTL.Value,handles.save_oct_frames_acquired_fct_C.Value);

    
               fer=ceil(size(hgf,1)./(2*handles.save_oct_frames_acquired_fct_C.Value));%fer should be 100*binning factor

    
               as=handles.save_oct_frames_acquired_fct_C.Value;
    
               for pp=1:as
                   for jj=1:2%use the initial loop for cleaner reading
                           hgf(1+(pp-1)*2*fer+(jj-1)*fer:jj*fer+(pp-1)*2*fer,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value)+ones(fer,1).*Value_Vo(1,pp);
                   end 
               end
                figure(852);plot(hgf(:,1));hold on;plot(hgf(:,2));hold on;plot(hgf(:,3)) 

                handles.TTL_output_save_2=repmat(hgf, [50, 1]);
           end 
       elseif mo==3
           446
           cy=18;

           lkj=linspace(0,9,cy) ; 
           lkj=repelem(lkj, 1,handles.save_oct_binning.Value*10^2);
           lkj=circshift(lkj,-floor((100-handles.save_oct_duty_cycle_TTL.Value)/2));
           fds=repmat(fds,[cy 1]);
           fds(:,2)=lkj.';
           fds=repmat(fds, [round(handles.save_oct_frames_acquired_fct_C.Value/cy), 1]);

           handles.TTL_output_save_2=repmat(fds, [100, 1]);

           kkl=repmat(fds, [10, 1]);
           whos kkl
       end
    case 2
        % time DC removed
        %no piezo motion
        

        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 

        
    case 3
        %2-phases mode
        
        fdss=fds;

        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,3)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
        end

        fdss=circshift(fdss,ceil(ns/2));

        hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  

        fer=ceil(size(hgf,1)./2);

        for jj=1:2%use the initial loop for cleaner reading
            hgf(1+(jj-1)*fer:jj*fer,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);
        end   

        figure(234)
        plot(hgf(:,1))
        hold on
        plot(hgf(:,2))

        handles.TTL_output_save=repmat(hgf,[ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
        
        %%%%
%         fds=repmat(fds, [2, 1]);
%         
%         for jj=1:2
%             
%             fds(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);
% 
%         end
%         
%         if handles.save_oct_binning.Value>1
%             fds=repelem(fds,handles.save_oct_binning.Value,1);
%             handles.TTL_output_save=repmat(fds,...
%                 [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
%         else
%             handles.TTL_output_save=repmat(fds,...
%                 [Ns/2, 1]); %
%         end
    case 4 
        %4-phases mode
        
        fdss=fds;

        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,3)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
        end

        fdss=circshift(fdss,ceil(ns/2));

        hgf=repmat(fdss, [4*handles.save_oct_binning.Value, 1]);  

        fer=ceil(size(hgf,1)./4);

        for jj=1:4%use the initial loop for cleaner reading
            hgf(1+(jj-1)*fer:jj*fer,2)=ones(fer,1).*(jj-1)*((master.V_c_TTL.Value)./3);
        end   

        figure(234)
        plot(hgf(:,1))
        hold on
        plot(hgf(:,2))

        handles.TTL_output_save=repmat(hgf,[ceil(Ns./(4.*handles.save_oct_binning.Value)), 1]);
       
        %%%%
%         fds=repmat(fds, [4, 1]);
%         
%         for jj=1:2
%             
%             fds(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);
% 
%         end
%         
%         if handles.save_oct_binning.Value>1
%             fds=repelem(fds,handles.save_oct_binning.Value,1);
%             handles.TTL_output_save=repmat(fds,...
%                 [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
%         else
%             handles.TTL_output_save=repmat(fds,...
%                 [Ns/2, 1]); %
%         end

    case 6
        %multi-phases mode
        handles.save_oct_frames_acquired_fct_C.Value=master.dot_pc_TTL.Value*master.n_o_c_TTL.Value...
            *handles.save_oct_binning.Value;
        handles.save_oct_frames_acquired_fct_C.String=num2str(handles.save_oct_frames_acquired_fct_C.Value);
        
        fds=repmat(fds, [master.dot_pc_TTL.Value*master.n_o_c_TTL.Value, 1]);

        for ii=1:master.n_o_c_TTL.Value
            for jj=1:master.dot_pc_TTL.Value
                
                fds(1+(jj-1)*100+(ii-1)*100*master.dot_pc_TTL.Value:jj*100+(ii-1)*100*master.dot_pc_TTL.Value,2)=...
                    ones(100,1).*(jj-1)*(master.V_c_TTL.Value/master.dot_pc_TTL.Value)+(ii-1)*master.V_c_TTL.Value;

            end
        end
        
        if handles.save_oct_binning.Value==1
        handles.TTL_output_save=repmat(fds, [20, 1]);   %it seems that the cycle needs to be reppeated  many times in order to avoid the camera crashing...
        else           
            fds1=repmat(fds,[handles.save_oct_binning.Value]);
            fds1(:,2)=repelem(fds(:,2),handles.save_oct_binning.Value);
            fds=fds1;
            handles.TTL_output_save=repmat(fds,...
                [20*5*3./(handles.save_oct_binning.Value), 1]);
        end
    case 7
        %dffoct
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
    case 8 %dffoct + 2phase
        
  
        mo=2;
        
        
        if mo==1
     
        fdss=fds;
        
        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,3)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
        end

        fdss=circshift(fdss,ceil(ns/2));
     
    hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  
    
    fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading   
            hgf(1+(jj-1)*fer:jj*fer,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
        figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))


    
%careful: if duty> 50% it does not work for the 2 phases
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %2 phase limited bandwidth
%     if ((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value)))<20%20 is an arbitary value representing enabling to wait for the piezo to reach its final position before logging the data
%         r=ceil(20/((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value))));
%         hgf=[hgf(1:100*handles.save_oct_binning.Value,:);zeros(handles.save_oct_duty_cycle_TTL.Value*r,2);hgf(1+100*handles.save_oct_binning.Value:end,:)];
%     end
    
    handles.TTL_output_save=repmat(hgf,[ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
            
            fds=repmat(fds, [10*3, 1]);
            
            
            fds(:,2)=0.0.*ones(size(fds,1),1);%%%%%%%%%%%%%%%%%%%%%%%%%%
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
        kkl=repmat(fds, [ceil(Ns./(10*3)), 1]);
        whos kkl
 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        elseif mo==2
%%%%%%%%%%%%%%%%%%%%%%%%%%test multiphase
 fdss=fds;
        
        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,3)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
%             gfd
        end


        fdss=circshift(fdss,ceil(ns/2));

     
    hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  
    
    fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(jj-1)*fer:jj*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
    
    
        figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))


    
%careful: if duty> 50% it does not work for the 2 phases
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %2 phase limited bandwidth
%     if ((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value)))<20%20 is an arbitary value representing enabling to wait for the piezo to reach its final position before logging the data
%         r=ceil(20/((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value))));
%         hgf=[hgf(1:100*handles.save_oct_binning.Value,:);zeros(handles.save_oct_duty_cycle_TTL.Value*r,2);hgf(1+100*handles.save_oct_binning.Value:end,:)];
%     end
    
    handles.TTL_output_save=repmat(hgf,[ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
   po=1;
   if po==1
       445
          lkj=linspace(0,9,handles.save_oct_frames_acquired_fct_C.Value*handles.save_oct_binning.Value) ;  

          lkj=repelem(lkj, 1, 10^2);
            fds=repmat(fds, [handles.save_oct_frames_acquired_fct_C.Value*handles.save_oct_binning.Value, 1]);

            fds(:,2)=lkj.';
            
            
        handles.TTL_output_save_2=repmat(fds, [100, 1]);
        
        kkl=repmat(fds, [10, 1]);
        whos kkl
        
   elseif po==2

       
        fdss=fds;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        fdss=circshift(fdss,ceil(ns/2));
%             figure(862);plot(fdss(:,1));hold on;plot(fdss(:,2));hold on;plot(fdss(:,3)) 
            hgf=repmat(fdss, [2*handles.save_oct_binning.Value*handles.save_oct_frames_acquired_fct_C.Value, 1]); 
            
            Value_Vo=linspace(0,10-master.V_c_TTL.Value,handles.save_oct_frames_acquired_fct_C.Value);

    
    fer=ceil(size(hgf,1)./(2*handles.save_oct_frames_acquired_fct_C.Value));%fer should be 100*binning factor

    
    as=handles.save_oct_frames_acquired_fct_C.Value;
    
    for pp=1:as
        
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(pp-1)*2*fer+(jj-1)*fer:jj*fer+(pp-1)*2*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value)+ones(fer,1).*Value_Vo(1,pp);

    end 
    end
    
    
    figure(852);plot(hgf(:,1));hold on;plot(hgf(:,2));hold on;plot(hgf(:,3)) 
    
    handles.TTL_output_save_2=repmat(hgf, [50, 1]);

   end

        end
        
         
    case 9
        %V
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
    case 14
          fdss=fds;
        
        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,2)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
%             gfd
        end
        
        
%                 figure(234)
%     plot(fdss(:,1))
%     hold on
%     plot(fdss(:,2))
        
%            tot2P=2.*handles.save_oct_accu.Value.*handles.save_oct_binning.Value;
%            totD=handles.save_oct_frames_acquired_fct_C.Value.*handles.save_oct_accu.Value.*handles.save_oct_binning.Value;
%            totW=handles.save_oct_waste.Value;
%            tot=((2+handles.save_oct_frames_acquired_fct_C.Value).*...
%         handles.save_oct_accu.Value.*...
%         handles.save_oct_binning.Value)+handles.save_oct_waste.Value;

        fdss=circshift(fdss,ceil(ns/2));
%         hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);
        
%         for jj=1:2
%             
%             fdss(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);
% 
%         end
     
    hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  
    
    fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(jj-1)*fer:jj*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
    
    
        figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))


    
%careful: if duty> 50% it does not work for the 2 phases
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %2 phase limited bandwidth
%     if ((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value)))<20%20 is an arbitary value representing enabling to wait for the piezo to reach its final position before logging the data
%         r=ceil(20/((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value))));
%         hgf=[hgf(1:100*handles.save_oct_binning.Value,:);zeros(handles.save_oct_duty_cycle_TTL.Value*r,2);hgf(1+100*handles.save_oct_binning.Value:end,:)];
%     end
    
    handles.TTL_output_save=repmat(hgf,...
                [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
            
            fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
        
  
% lol1=handles.TTL_output_save;
% lol2=handles.TTL_output_save_2;


        
        
%     figure(234)
%     plot(lol1(:,1))
%     hold on
%     plot(lol1(:,2))
%      figure(456)
%     plot(lol2(:,1))
%      hold on
%     plot(lol2(:,2))
    
%     hgf=repmat(hgf, [handles.save_oct_accu.Value, 1]); 
%     fds=repmat(fds, [totD+totW, 1]); 
%     
%     fds=[hgf;fds];
%     
%     handles.TTL_output_save=repmat(fds, [ceil(Ns./(tot)), 1]); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    case 15
        dff_photo=1
        
        
        fdss=fds;
        
        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,3)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
%             gfd
        end
        
        

        fdss=circshift(fdss,ceil(ns/2));

     
    hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  
    
    fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(jj-1)*fer:jj*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
    
    
        figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))
    hold on
    plot(hgf(:,3))


   
    
    handles.TTL_output_save=repmat(hgf,...
                [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
            
            fdss=fds;
            
                fds=repmat(fds, [10*3, 1]);
% llk=repmat(fds, [ceil(Ns./(10*3)), 1]);
% whos llk
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]);        
            
            
       time_expo_photo=5;%10ms  
       time_response_photo=2500; %500 ms
       
       Ratio_photo=(time_expo_photo/handles.save_oct_expo_time.Value);
       Ratio_response=(time_response_photo/handles.save_oct_expo_time.Value);
       
       fdss=repmat(fdss,[ceil((Ratio_photo+Ratio_response)),1]);
       fdss(1:ceil(100*Ratio_photo),3)=5.*ones((ceil(100*Ratio_photo)),1);

            
  
          figure(345);plot(fdss(:,1));hold on;plot(fdss(:,2));hold on;plot(fdss(:,3))   
          
% kkj=repmat(fdss, [ceil(Ns./(length(fdss))), 1]);
% whos kkj

        handles.TTL_output_save_3=repmat(fdss, [ceil(Ns./(100)), 1]); 
%         a=repmat(fdss, [ceil(Ns./(100)), 1]);
%         whos a

    case 16 
        %Raw photo stimu
        rawstimu=1
        fdss=fds;
        
             time_expo_photo=100;%10ms    % Manually change this value
       time_response_photo=100; %500 ms     Manually change this value
       
       
%        fds=repmat(fds, [10*3, 1]);
%         handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
%        
       
       %%%%%%%
       time_acqui=2500;% 10 seconds
       
       Ratio_photo=(time_expo_photo*handles.save_oct_frame_per_second.Value/1000);
       Ratio_response=(time_response_photo*handles.save_oct_frame_per_second.Value/1000);
       
       %%
       Ratio_acqui=(time_acqui*handles.save_oct_frame_per_second.Value/1000);
       
       whos fdss
       fdss=repmat(fdss,[ceil((Ratio_photo+Ratio_response)),1]);
       
       
       hgff=fdss;
       
       %figure(123);plot(hgff(:,1));hold on;plot(hgff(:,2));hold on;plot(hgff(:,3)) 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
       fdss(ceil(100*Ratio_response)+1:end,3)=5.*ones((ceil(100*Ratio_photo)),1);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        fdss(1:ceil(100*Ratio_photo),3)=5.*ones((ceil(100*Ratio_photo)),1);

%modification

fdss=circshift(fdss,13000);
            
  
        figure(345);plot(fdss(:,1));hold on;plot(fdss(:,2));hold on;plot(fdss(:,3))   
          
        fdss=repmat(fdss, [10*3, 1]);
%         handles.TTL_output_save_2=repmat(fdss, [ceil(Ns./((Ratio_photo+Ratio_response).*10*3)), 1]); 
%         
        hgff=repmat(hgff, [10*3, 1]);
%         handles.TTL_output_save=repmat(hgff, [ceil(Ns./((Ratio_photo+Ratio_response).*10*3)), 1]); 
        
        hgff=repmat(hgff, [10, 1]);
        fdss=repmat(fdss, [10, 1]);
        %%%%
        
%         fds=[hgff(1:5020*100,:);fdss(1:5000*100,:)];

%old TTL
% fds=[hgff(1:ceil(handles.save_oct_frames_acquired_fct_C.Value*100/2),:);fdss(1:ceil(handles.save_oct_frames_acquired_fct_C.Value*100/2),:)];
fds=[hgff(1:ceil(handles.save_oct_frames_acquired_fct_C.Value*100/2),:);fdss(1:ceil(handles.save_oct_frames_acquired_fct_C.Value*100/2),:)];
         handles.TTL_output_save=repmat(fds,10,1);
%  handles.TTL_output_save=fds;
        
        
        
      
        
        
        
        
end

figure(123);plot(fds(:,1));hold on;plot(fds(:,2));hold on;plot(fds(:,3)) 
end
