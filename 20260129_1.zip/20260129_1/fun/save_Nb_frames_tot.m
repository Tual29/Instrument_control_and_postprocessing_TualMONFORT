function tot=save_Nb_frames_tot(handles)
if handles.save_oct_mode.Value==8
%     tot=((2+handles.save_oct_frames_acquired_fct_C.Value).*...
%         handles.save_oct_accu.Value.*...
%         handles.save_oct_binning.Value)+handles.save_oct_waste.Value;
    
    tot(1,1)=2*handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        +handles.save_oct_waste.Value;
    tot(1,2)=handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        .*handles.save_oct_frames_acquired_fct_C.Value;
    
elseif handles.save_oct_mode.Value==15
    tot(1,1)=2*handles.save_oct_accu.Value.*handles.save_oct_binning.Value;
    tot(1,2)=handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        .*handles.save_oct_frames_acquired_fct_C.Value+handles.save_oct_waste.Value;
    tot(1,3)=tot(1,2);
    elseif handles.save_oct_mode.Value==16
    tot(1,1)=handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        .*handles.save_oct_frames_acquired_fct_C.Value+handles.save_oct_waste.Value;
    tot(1,2)=tot(1,1);

    
else
    tot=((handles.save_oct_frames_acquired_fct_C.Value).*...
        handles.save_oct_accu.Value.*...
        handles.save_oct_binning.Value)+handles.save_oct_waste.Value;
end