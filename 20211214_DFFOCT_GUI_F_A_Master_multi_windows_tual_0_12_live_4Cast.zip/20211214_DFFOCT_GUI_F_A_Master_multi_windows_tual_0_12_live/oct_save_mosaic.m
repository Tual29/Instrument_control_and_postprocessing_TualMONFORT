function varargout = oct_save_mosaic(varargin)
% OCT_SAVE_MOSAIC MATLAB code for oct_save_mosaic.fig
%      OCT_SAVE_MOSAIC, by itself, creates a new OCT_SAVE_MOSAIC or raises the existing
%      singleton*.
%
%      H = OCT_SAVE_MOSAIC returns the handle to a new OCT_SAVE_MOSAIC or the handle to
%      the existing singleton*.
%
%      OCT_SAVE_MOSAIC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OCT_SAVE_MOSAIC.M with the given input arguments.
%
%      OCT_SAVE_MOSAIC('Property','Value',...) creates a new OCT_SAVE_MOSAIC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before oct_save_mosaic_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to oct_save_mosaic_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help oct_save_mosaic

% Last Modified by GUIDE v2.5 15-Apr-2022 13:51:58

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @oct_save_mosaic_OpeningFcn, ...
                   'gui_OutputFcn',  @oct_save_mosaic_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before oct_save_mosaic is made visible.
function oct_save_mosaic_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to oct_save_mosaic (see VARARGIN)

% Choose default command line output for oct_save_mosaic
handles.output = hObject;


handles.save_mosaic_step_length_y.Value=200;
handles.save_mosaic_step_length_y.String=num2str(handles.save_mosaic_step_length_y.Value);

handles.save_mosaic_step_length_x.Value=200;
handles.save_mosaic_step_length_x.String=num2str(handles.save_mosaic_step_length_x.Value);

handles.save_mosaic_Nx.Value=2;
handles.save_mosaic_Nx.String=num2str(handles.save_mosaic_Nx.Value);

handles.save_mosaic_Ny.Value=2;
handles.save_mosaic_Ny.String=num2str(handles.save_mosaic_Ny.Value);


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes oct_save_mosaic wait for user response (see UIRESUME)
% uiwait(handles.oct_save_mosaic);

function handles=mosaic_coordinate_update(handles)


moz_y=zeros(1,handles.save_mosaic_Ny.Value);
moz_x=zeros(1,handles.save_mosaic_Nx.Value);

moz_y=linspace(0,(handles.save_mosaic_Ny.Value-1)*handles.save_mosaic_step_length_y.Value,handles.save_mosaic_Ny.Value);
moz_x=linspace(0,(handles.save_mosaic_Nx.Value-1)*handles.save_mosaic_step_length_x.Value,handles.save_mosaic_Nx.Value);
moz_x
moz_y
handles.mosaic_coordinate_x=moz_x;
handles.mosaic_coordinate_y=moz_y;




% --- Outputs from this function are returned to the command line.
function varargout = oct_save_mosaic_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function save_mosaic_Nx_Callback(hObject, eventdata, handles)
handles.save_mosaic_Nx.Value=str2double(handles.save_mosaic_Nx.String);

handles=mosaic_coordinate_update(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_mosaic_Nx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_mosaic_Nx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_mosaic_Ny_Callback(hObject, eventdata, handles)
handles.save_mosaic_Ny.Value=str2double(handles.save_mosaic_Ny.String);
handles=mosaic_coordinate_update(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_mosaic_Ny_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_mosaic_Ny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_mosaic_step_length_x_Callback(hObject, eventdata, handles)
handles.save_mosaic_step_length_x.Value=str2double(handles.save_mosaic_step_length_x.String);
handles=mosaic_coordinate_update(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function save_mosaic_step_length_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_mosaic_step_length_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_mosaic_step_length_y_Callback(hObject, eventdata, handles)
handles.save_mosaic_step_length_y.Value=str2double(handles.save_mosaic_step_length_y.String);
handles=mosaic_coordinate_update(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function save_mosaic_step_length_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_mosaic_step_length_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
