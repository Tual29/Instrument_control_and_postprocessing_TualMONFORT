Hh=zeros(1440,1440,81);
Hh(:,:,1)=H(:,:,1);

v1=[-65000:500:65000];


for ii=2:81
ii

if ii==2
    b=sum(abs(reshape(imgaussfilt(H(:,:,ii-1),2),[],1)-(reshape(imgaussfilt(H(:,:,ii),2),[],1)+(v1))));
    [f1 f2]=min(b);
% end

v2=[v1(1,f2)-1000:v1(1,f2)+1000];

c=sum(abs(reshape(imgaussfilt(H(:,:,ii-1),2),[],1)-(reshape(imgaussfilt(H(:,:,ii),2),[],1)+(v2))));

[g1 g2]=min(c);

Hh(:,:,ii)=H(:,:,ii)+v2(1,g2);

else
    b=sum(abs(reshape(imgaussfilt(Hh(:,:,ii-1),2),[],1)-(reshape(imgaussfilt(H(:,:,ii),2),[],1)+(v1))));
    [f1 f2]=min(b);
% end

v2=[v1(1,f2)-1000:v1(1,f2)+1000];

c=sum(abs(reshape(imgaussfilt(Hh(:,:,ii-1),2),[],1)-(reshape(imgaussfilt(H(:,:,ii),2),[],1)+(v2))));

[g1 g2]=min(c);

Hh(:,:,ii)=H(:,:,ii)+v2(1,g2);
    
end

end

%%

imwrite(uint16(Hh(:,:,1)),'HshG.tif');


for k = 2:81
    k
    imwrite(uint16(Hh(:,:,k)), 'HshG.tif', 'writemode', 'append');

end
