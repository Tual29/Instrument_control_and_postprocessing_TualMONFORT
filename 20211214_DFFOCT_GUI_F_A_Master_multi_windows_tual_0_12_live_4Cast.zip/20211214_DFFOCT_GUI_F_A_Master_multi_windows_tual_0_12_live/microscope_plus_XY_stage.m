function varargout = microscope_plus_XY_stage(varargin)
% MICROSCOPE_PLUS_XY_STAGE MATLAB code for microscope_plus_XY_stage.fig
%      MICROSCOPE_PLUS_XY_STAGE, by itself, creates a new MICROSCOPE_PLUS_XY_STAGE or raises the existing
%      singleton*.
%
%      H = MICROSCOPE_PLUS_XY_STAGE returns the handle to a new MICROSCOPE_PLUS_XY_STAGE or the handle to
%      the existing singleton*.
%
%      MICROSCOPE_PLUS_XY_STAGE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MICROSCOPE_PLUS_XY_STAGE.M with the given input arguments.
%
%      MICROSCOPE_PLUS_XY_STAGE('Property','Value',...) creates a new MICROSCOPE_PLUS_XY_STAGE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before microscope_plus_XY_stage_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to microscope_plus_XY_stage_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help microscope_plus_XY_stage

% Last Modified by GUIDE v2.5 13-Apr-2022 14:30:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @microscope_plus_XY_stage_OpeningFcn, ...
                   'gui_OutputFcn',  @microscope_plus_XY_stage_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before microscope_plus_XY_stage is made visible.
function microscope_plus_XY_stage_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to microscope_plus_XY_stage (see VARARGIN)

% Choose default command line output for microscope_plus_XY_stage
handles.output = hObject;

% Update handles structure



    current_directory_path=cd;
    [gui, mmc, acq]=ini_MM_connect(current_directory_path);
    handles.gui=gui;
    handles.mmc=mmc;
    handles.acq=acq;
    handles=ini_MM_hardware_input(handles);
    handles.ref_x0=handles.absolute_x.Value;
    handles.ref_y0=handles.absolute_y.Value;
    handles.ref_z0=handles.absolute_z.Value;
    
guidata(hObject, handles);

% UIWAIT makes microscope_plus_XY_stage wait for user response (see UIRESUME)
% uiwait(handles.microscope_plus_XY_stage);


% --- Outputs from this function are returned to the command line.
function varargout = microscope_plus_XY_stage_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in up_z.
function up_z_Callback(hObject, eventdata, handles)
handles.mmc.setPosition('FocusDrive',handles.mmc.getPosition()+handles.delta_z.Value);
handles.mmc.waitForSystem();
handles.absolute_z.Value=handles.mmc.getPosition();
handles.absolute_z.String=num2str(handles.absolute_z.Value);

% --- Executes on button press in down_z.
function down_z_Callback(hObject, eventdata, handles)
handles.mmc.setPosition('FocusDrive',handles.mmc.getPosition()-handles.delta_z.Value);
handles.mmc.waitForSystem();
handles.absolute_z.Value=handles.mmc.getPosition();
handles.absolute_z.String=num2str(handles.absolute_z.Value);


function delta_z_Callback(hObject, eventdata, handles)
handles.delta_z.Value=str2double(handles.delta_z.String);

% --- Executes during object creation, after setting all properties.
function delta_z_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_z0.
function save_z0_Callback(hObject, eventdata, handles)
handles.ref_z0=handles.absolute_z.Value;
guidata(hObject, handles);



function absolute_z_Callback(hObject, eventdata, handles)
handles.absolute_z.Value=str2double(handles.absolute_z.String);
handles.mmc.setPosition('FocusDrive',handles.absolute_z.Value);

% --- Executes during object creation, after setting all properties.
function absolute_z_CreateFcn(hObject, eventdata, handles)
% hObject    handle to absolute_z (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in go_to_z0.
function go_to_z0_Callback(hObject, eventdata, handles)
handles.mmc.setPosition('FocusDrive',handles.ref_z0);



% --- Executes on button press in up_y.
function up_y_Callback(hObject, eventdata, handles)
handles.mmc.setRelativeXYPosition(handles.mmc.getXYStageDevice(), 0, +handles.delta_y.Value );

handles.mmc.waitForSystem();
handles.absolute_y.Value=handles.mmc.getYPosition();
handles.absolute_y.String=num2str(handles.absolute_y.Value);

% --- Executes on button press in down_y.
function down_y_Callback(hObject, eventdata, handles)
handles.mmc.setRelativeXYPosition(handles.mmc.getXYStageDevice(), 0, -handles.delta_y.Value );

handles.mmc.waitForSystem();
handles.absolute_y.Value=handles.mmc.getYPosition();
handles.absolute_y.String=num2str(handles.absolute_y.Value);


function delta_y_Callback(hObject, eventdata, handles)
handles.delta_y.Value=str2double(handles.delta_y.String);


% --- Executes during object creation, after setting all properties.
function delta_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in right_x.
function right_x_Callback(hObject, eventdata, handles)
if (handles.mmc.getXPosition()-handles.delta_x.Value)>4.6913e+04
    'out of range'
else
handles.mmc.setRelativeXYPosition(handles.mmc.getXYStageDevice(), handles.delta_x.Value, 0 );

handles.mmc.waitForSystem();
handles.absolute_x.Value=handles.mmc.getXPosition();
handles.absolute_x.String=num2str(handles.absolute_x.Value);
end



% --- Executes on button press in left_x.
function left_x_Callback(hObject, eventdata, handles)
if (handles.mmc.getXPosition()-handles.delta_x.Value)<-4.6913e+04
else
handles.mmc.setRelativeXYPosition(handles.mmc.getXYStageDevice(), -handles.delta_x.Value, 0 );

handles.mmc.waitForSystem();
handles.absolute_x.Value=handles.mmc.getXPosition();
handles.absolute_x.String=num2str(handles.absolute_x.Value);
end


function delta_x_Callback(hObject, eventdata, handles)
handles.delta_x.Value=str2double(handles.delta_x.String);


% --- Executes during object creation, after setting all properties.
function delta_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function absolute_y_Callback(hObject, eventdata, handles)
handles.absolute_y.Value=str2double(handles.absolute_y.String);
handles.mmc.setXYPosition(handles.absolute_x.Value, handles.absolute_y.Value);
handles.mmc.waitForSystem();


% --- Executes during object creation, after setting all properties.
function absolute_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to absolute_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function absolute_x_Callback(hObject, eventdata, handles)
handles.absolute_x.Value=str2double(handles.absolute_x.String);
handles.mmc.setXYPosition(handles.absolute_x.Value, handles.absolute_x.Value);
handles.mmc.waitForSystem();

% --- Executes during object creation, after setting all properties.
function absolute_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to absolute_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_y0.
function save_y0_Callback(hObject, eventdata, handles)
handles.ref_y0=handles.absolute_y.Value;
guidata(hObject, handles);


% --- Executes on button press in save_x0.
function save_x0_Callback(hObject, eventdata, handles)
handles.ref_x0=handles.absolute_x.Value;
guidata(hObject, handles);


% --- Executes on button press in go_to_y0.
function go_to_y0_Callback(hObject, eventdata, handles)
handles.mmc.setXYPosition(handles.ref_x0, handles.ref_y0);
handles.mmc.waitForSystem();


% --- Executes on button press in go_to_x0.
function go_to_x0_Callback(hObject, eventdata, handles)
handles.mmc.setXYPosition(handles.ref_x0, handles.ref_y0);
handles.mmc.waitForSystem();


% --- Executes on selection change in turret_epi_1.
function turret_epi_1_Callback(hObject, eventdata, handles)
handles.mmc.setProperty('Dichroic 1','State', handles.turret_epi_1.Value-1);
handles.mmc.waitForSystem();

% --- Executes during object creation, after setting all properties.
function turret_epi_1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to turret_epi_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in turret_epi_2.
function turret_epi_2_Callback(hObject, eventdata, handles)
handles.mmc.setProperty('Dichroic 2','State', handles.turret_epi_2.Value-1);
handles.mmc.waitForSystem();

% --- Executes during object creation, after setting all properties.
function turret_epi_2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to turret_epi_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in shutter_epi_11.
function shutter_epi_11_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1
1
%     handles.shutter_epi_11.String='Open';
%     handles.shutter_epi_11.BackgroundColor=[0 1 0];
%     handles.mmc.setProperty('EpiShutter 1','State', 1);
%     handles.mmc.waitForSystem();

   
elseif get(hObject,'Value')==0
0
%     handles.shutter_epi_11.String='Close';
% 
%     handles.shutter_epi_11.BackgroundColor=[1 0 0];
%     handles.mmc.setProperty('EpiShutter 1','State', 0);
%     handles.mmc.waitForSystem();
end


% --- Executes on button press in shutter_epi_22.
function shutter_epi_22_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1
1
%     handles.shutter_epi_22.String='Open';
%     handles.shutter_epi_22.BackgroundColor=[0 1 0];
%     handles.mmc.setProperty('EpiShutter 2','State', 1);
%     handles.mmc.waitForSystem();

   
elseif get(hObject,'Value')==0
0
%     handles.shutter_epi_22.String='Close';
% 
%     handles.shutter_epi_22.BackgroundColor=[1 0 0];
%     handles.mmc.setProperty('EpiShutter 2','State', 0);
%     handles.mmc.waitForSystem();
end


% --- Executes on selection change in camera_port.
function camera_port_Callback(hObject, eventdata, handles)
% hObject    handle to camera_port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns camera_port contents as cell array
%        contents{get(hObject,'Value')} returns selected item from camera_port


% --- Executes during object creation, after setting all properties.
function camera_port_CreateFcn(hObject, eventdata, handles)
% hObject    handle to camera_port (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in condenser_filter_wheel.
function condenser_filter_wheel_Callback(hObject, eventdata, handles)
% hObject    handle to condenser_filter_wheel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns condenser_filter_wheel contents as cell array
%        contents{get(hObject,'Value')} returns selected item from condenser_filter_wheel


% --- Executes during object creation, after setting all properties.
function condenser_filter_wheel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to condenser_filter_wheel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function brightness_trans_Callback(hObject, eventdata, handles)
handles.brightness_trans.Value=str2double(handles.brightness_trans.String);
handles.mmc.setProperty('TransmittedIllumination 2','Brightness', handles.brightness_trans.Value);


% --- Executes during object creation, after setting all properties.
function brightness_trans_CreateFcn(hObject, eventdata, handles)
% hObject    handle to brightness_trans (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function aperature_trans_Callback(hObject, eventdata, handles)
% hObject    handle to aperature_trans (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of aperature_trans as text
%        str2double(get(hObject,'String')) returns contents of aperature_trans as a double


% --- Executes during object creation, after setting all properties.
function aperature_trans_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aperature_trans (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in transmition_shutter.
function transmition_shutter_Callback(hObject, eventdata, handles)
% hObject    handle to transmition_shutter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of transmition_shutter


% --- Executes when user attempts to close microscope_plus_XY_stage.
function microscope_plus_XY_stage_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to microscope_plus_XY_stage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

delete(handles.gui);
delete(handles.mmc);
delete(handles.acq);
delete(hObject);


% --- Executes on button press in delay_adjust_enable.
function delay_adjust_enable_Callback(hObject, eventdata, handles)
% hObject    handle to delay_adjust_enable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of delay_adjust_enable


% --- Executes during object deletion, before destroying properties.
function microscope_plus_XY_stage_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to microscope_plus_XY_stage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
