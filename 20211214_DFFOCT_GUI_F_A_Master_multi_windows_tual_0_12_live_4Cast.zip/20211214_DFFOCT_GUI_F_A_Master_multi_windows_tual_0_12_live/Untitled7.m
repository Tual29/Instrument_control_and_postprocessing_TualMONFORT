H= double(zeros(1440,1440,81));
S= double(zeros(1440,1440,81));
V= double(zeros(1440,1440,81));

for ii=1:81
    ii
H(:,:,ii)=(double(imread('H.tif',ii)));
S(:,:,ii)=(double(imread('S.tif',ii)));
V(:,:,ii)=(double(imread('CuS.tif',ii)));
end

%%

AA=H;


Bh=zeros(1440,1440,81);
Bh(:,:,1)=AA(:,:,1);

v1=[-65000:500:65000];

bl=2;
for ii=2:81
ii

if ii==2
    b=sum(0.00001.*(abs(reshape(imgaussfilt(AA(:,:,ii-1),bl),[],1)-(reshape(imgaussfilt(AA(:,:,ii),bl),[],1)+(v1)))).^3);
    [f1 f2]=min(b);
% end

v2=[v1(1,f2)-1000:v1(1,f2)+1000];

c=sum(0.00001.*(abs(reshape(imgaussfilt(AA(:,:,ii-1),bl),[],1)-(reshape(imgaussfilt(AA(:,:,ii),bl),[],1)+(v2)))).^3);

[g1 g2]=min(c);

Bh(:,:,ii)=AA(:,:,ii)+v2(1,g2);

else
    b=sum(0.00001.*(abs(reshape(imgaussfilt(Bh(:,:,ii-1),bl),[],1)-(reshape(imgaussfilt(AA(:,:,ii),bl),[],1)+(v1)))).^3);
    [f1 f2]=min(b);
% end

v2=[v1(1,f2)-1000:v1(1,f2)+1000];

c=sum(0.00001.*(abs(reshape(imgaussfilt(Bh(:,:,ii-1),bl),[],1)-(reshape(imgaussfilt(AA(:,:,ii),bl),[],1)+(v2)))).^3);

[g1 g2]=min(c);

Bh(:,:,ii)=AA(:,:,ii)+v2(1,g2);
    
end

end

%%

imwrite(uint16(Bh(:,:,1)),'Hsh1c.tif');


for k = 2:81
    k
    imwrite(uint16(Bh(:,:,k)), 'Hsh1c.tif', 'writemode', 'append');

end
