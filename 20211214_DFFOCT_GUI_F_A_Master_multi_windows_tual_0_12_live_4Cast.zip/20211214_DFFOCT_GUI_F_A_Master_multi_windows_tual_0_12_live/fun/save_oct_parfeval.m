function save_oct_parfeval(I,path,t,mode,name)


b=size(I,3);
% a=rand(10,10,10);
% save('test.mat','a','-v7.3','-nocompression')
%save([path num2str(t) 'test1.mat'],'b','-v7.3','-nocompression')
switch mode
    case 1
        
        save([path '\' num2str(t) 'test.mat'],'I','-v7.3','-nocompression')
    case 2
        
        %check if the function can be called from fun in parfeval mode
        %in the meanwhile, I do not use the function
        mi=min(I(:));
        ma=max(I(:));
        writematrix([mi;ma],[path '\' num2str(t) name 'min_max.txt']);
        if b==1
        imwrite(uint16(65535.*rescale(I)),[path '\' name 't' num2str(t) '.tif'])
        else
            I=rescale(I);
            for jj=1:b
            if jj==1
                imwrite(uint16(65536.*rescale(I(:,:,1))),[path '\' name 't' num2str(t) '.tif'])
            else
                imwrite(uint16(65536.*rescale(I(:,:,jj))),[path '\' name 't' num2str(t) '.tif'], 'writemode', 'append');
            end
            end
        end
end