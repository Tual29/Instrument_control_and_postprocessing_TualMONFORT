function [Ht,St,Vt,handles] = HSV_gpu_J_tualmodified_1(im,handles)
tic
s = size(im);
% freq_min = round(s(3).*0.03);   % Minimum frequency to consider in Fourier domain.

% Hard coded parameters
n_std = 50;     % Number of sample in the moving STD.
freq_min = 4;   % Minimum frequency to consider in Fourier domain.

% We normalize each frame to remove sensor frame to frame instabilities.
im = double(squeeze(im));
s = size(im);

directMean = (mean(mean(im,1),2));

    im=single(im./directMean);

% We divide the image in 9 sub-images in order to reduce the memory
% footprint on the GPU (change it depending on your hardware).

        imGPU = gpuArray(single(im));
        V = zeros(s(1),s(2),s(3)/16,'single','gpuArray');
%         whos V

        for i = 1:floor((s(3)-n_std)/16)
%             a=std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
%             whos a
            V(:,:,i) = std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
            
        end
        V = gather(mean(V,3));
        
        % Average 4 samples
        imMean = zeros(s(1),s(2),s(3)/4,'single','gpuArray');
        for i = 1:s(3)/4
            imMean(:,:,i) = single(mean(imGPU(:,:,(i-1)*4+1:i*4),3));
        end
        clear imGPU
        
        % Compute Fourier transform and normalize as if it were a
        % probability distribution
        data_freq = abs(fft(imMean,[],3));
        clear imMean
        
        data_freq = data_freq(:,:,freq_min:s(3)/8+1);
        normL1 = reshape(repmat(sum(data_freq,3),1,s(3)/8-freq_min+2),s(1),s(2),s(3)/8-freq_min+2);
        data_freq = data_freq./normL1;
        clear normL1
%        whos data_freq
        
%         qsd=linspace(0,100/4,s(3)/8-2);
%         whos qsd
%         rez=repelem(gpuArray.linspace(0,100/4,s(3)/8-2),s(1)*s(2));
%         whos rez
%         %hgf=reshape(rez);
%         whos hgf
        %g=gpuArray.linspace(0,100/4,s(3)/8-2);
        f = reshape(repelem(gpuArray.linspace(0,handles.frame_per_second.Value/4,s(3)/8-2),s(1)*s(2)),s(1),s(2),s(3)/8-freq_min+2);
        %whos f % S component is computed as the probability distribution STD
        S = gather(sqrt(dot(data_freq,f.^2,3)-dot(data_freq,f,3).^2));
        data_freq = data_freq - reshape(repmat(min(data_freq,[],3),1,s(3)/8-2),s(1),s(2),s(3)/8-freq_min+2);
        % H component is computed as the probability distribution mean.
        H = gather(dot(data_freq,f,3));
        clear data_freq f
        
        
        
Ht=double(H);
St=double(S);
Vt=double(V);
toc