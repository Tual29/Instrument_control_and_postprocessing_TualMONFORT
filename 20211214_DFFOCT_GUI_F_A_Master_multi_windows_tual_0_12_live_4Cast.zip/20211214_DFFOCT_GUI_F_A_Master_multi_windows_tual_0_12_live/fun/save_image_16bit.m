function save_image_16bit(I,name)
mi=min(I(:));
ma=max(I(:));
writematrix([mi;ma],'min_max.txt');

imwrite(uint16(65535.*rescale(I)),[name '.tif'])