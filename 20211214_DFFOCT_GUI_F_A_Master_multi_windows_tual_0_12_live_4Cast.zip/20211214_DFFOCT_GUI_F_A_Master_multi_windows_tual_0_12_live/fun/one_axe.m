function handles=one_axe(handles)
axes(handles.axes_one)
caxis([handles.min_range_one.Value handles.max_range_one.Value])
hold off