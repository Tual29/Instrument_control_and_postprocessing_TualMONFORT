function save_image_stack(obj,event,handles,dd)

global I
global T

I=I+1;
T=T+1;


x=handles.z_steps;
move=round(handles.motors.sample.Units.positiontonative(x(I)*1e-6)*5); % Translates the value in microns to the number of microsteps.
handles.motors.sample.moverelative(move);






Image=squeeze(getdata(handles.vid_cam_oct));
Image=Image(:,:,20+1:end);

switch handles.complex_retrieval.Value
    
    case 1

       save([dd '\' num2str(T) 'Raw.mat'],'Image')
       
       handles.save_image.BackgroundColor=[0 1 0];
    
    case 3
        
        II=single(mean(Image(:,:,1:2:end)-Image(:,:,2:2:end),3));
        set(handles.gui1Handles.one,'CData',Image(:,:,1));
        set(handles.gui2Handles.two,'CData',II);
        save([dd '\' num2str(I) 'TwoPhase.mat'],'II')
        %save([dd '\' num2str(I) 'Raw.mat'],'Image')
        
    case 6
        
        
        [Iampl, Ephase]=multi_phases(gpuArray(single(Image)),handles.mode_multi_phase.Value);

        set(handles.raw,'CData',double(gather(Iampl)));
        set(handles.phase,'CData',double(gather(Ephase)));
    case 8
        II=single(mean(Image(:,:,1:2:end)-Image(:,:,2:2:end),3));
        
        set(handles.gui2Handles.two,'CData',II);
        if size(Image,3)<=128
            fds
        else
            fds
            
        end

        
end
stop(handles.vid_cam_oct)