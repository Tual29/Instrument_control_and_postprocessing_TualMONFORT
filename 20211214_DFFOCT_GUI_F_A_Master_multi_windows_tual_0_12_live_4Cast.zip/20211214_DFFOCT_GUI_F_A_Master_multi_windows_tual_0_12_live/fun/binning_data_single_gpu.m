function ImR=binning_data_single_gpu(im,step)
s=size(im);
tr=floor(s(3)/step);
ImR=reshape(mean(single(reshape(gpuArray(im(:,:,1:tr*step)),s(1)*s(2),step,[])),2),s(1),s(2),[]);