function handles=two_axe(handles)
axes(handles.axes_two)
caxis([handles.min_range_two.Value handles.max_range_two.Value])
hold off