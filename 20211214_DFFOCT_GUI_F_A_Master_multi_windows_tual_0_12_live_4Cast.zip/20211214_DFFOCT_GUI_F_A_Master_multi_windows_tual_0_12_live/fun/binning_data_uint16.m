function ImR=binning_data_uint16(im,step)
s=size(im);
ImR=zeros(s(1),s(2),floor(s(3)/step),'uint16');
for ii=1:ceil(s(3)/step)
           ImR(:,:,ii)=mean(im(:,:,(ii-1)*step+1:ii*step),3,'native');
end
