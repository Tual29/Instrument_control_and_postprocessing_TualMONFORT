function ImR=binning_data_single(im,step)
s=size(im);
tr=floor(s(3)/step);
ImR=reshape(mean(single(reshape(im(:,:,1:tr*step),s(1)*s(2),step,[])),2,'native'),s(1),s(2),[]);
