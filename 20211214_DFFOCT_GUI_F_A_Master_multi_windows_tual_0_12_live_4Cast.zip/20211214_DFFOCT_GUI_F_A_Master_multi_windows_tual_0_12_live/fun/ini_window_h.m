function handles=ini_window_h(handles)

handles.f=figure;

axes(handles.f)
handles.H=imagesc(1:1440,...
    1:1440,...
    zeros(1440,1440));
caxis([0 2048]);colorbar;colormap('jet');axis off
hold off
