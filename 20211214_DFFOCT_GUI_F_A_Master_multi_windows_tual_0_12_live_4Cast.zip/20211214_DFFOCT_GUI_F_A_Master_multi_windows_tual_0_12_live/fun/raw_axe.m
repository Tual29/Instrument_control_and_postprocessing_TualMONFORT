function handles=raw_axe(handles)
axes(handles.axes_raw)
caxis([handles.min_range_raw.Value handles.max_range_raw.Value])
hold off