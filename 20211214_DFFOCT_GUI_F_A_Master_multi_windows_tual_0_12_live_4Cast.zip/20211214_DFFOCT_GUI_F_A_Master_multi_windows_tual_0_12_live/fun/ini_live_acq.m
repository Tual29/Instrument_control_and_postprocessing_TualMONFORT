function handles=ini_live_acq(handles)
handles.live_oct_frame_per_second.Value=20;
handles.live_oct_frame_per_second.String=num2str(handles.live_oct_frame_per_second.Value);

handles.live_oct_expo_time.Value=10;
handles.live_oct_expo_time.String=num2str(handles.live_oct_expo_time.Value);

handles.live_oct_frames_acquired_fct_C.Value=2;
handles.live_oct_frames_acquired_fct_C.String=num2str(handles.live_oct_frames_acquired_fct_C.Value);

handles.live_oct_waste.Value=0;
handles.live_oct_waste.String=num2str(handles.live_oct_waste.Value);

handles.live_oct_binning.Value=1;
handles.live_oct_binning.String=num2str(handles.live_oct_binning.Value);

handles.live_oct_accu.String='1';
handles.live_oct_accu.Value=str2double(handles.live_oct_accu.String);

handles.live_oct_duty_cycle_TTL.String='40';
handles.live_oct_duty_cycle_TTL.Value=str2double(handles.live_oct_duty_cycle_TTL.String);

handles.live_oct_z0.String='4000';
handles.live_oct_z0.Value=str2double(handles.live_oct_z0.String);



handles.live_oct_mode.Value=1;


