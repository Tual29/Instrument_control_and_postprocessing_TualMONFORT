function a=get_oct_save_mosaic
g_m=findobj('tag','oct_save_mosaic');
a=guidata(g_m);