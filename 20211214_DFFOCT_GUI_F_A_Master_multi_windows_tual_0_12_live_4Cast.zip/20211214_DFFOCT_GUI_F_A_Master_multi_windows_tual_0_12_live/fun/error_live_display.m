function error_live_display(obj,event,handles)
stop(handles.master.vid_cam_oct)
stop(handles.master.d)
handles.master.d.Rate=handles.live_oct_frame_per_second.Value*100;
    
    queueOutputData(handles.master.d,handles.TTL_output_live);
    startBackground(handles.master.d);
    pause(0.1)
    

    set(handles.master.vid_cam_oct, 'FramesPerTrigger', Inf, 'LoggingMode', 'memory');
    
    handles.master.vid_cam_oct.FramesAcquiredFcnCount=handles.live_oct_frames_acquired_fct_C.Value;
    handles.master.vid_cam_oct.FramesAcquiredFcn={'live_display',handles};
    handles.master.vid_cam_oct.ErrorFcn = {'error_live_display',handles};
    start(handles.master.vid_cam_oct)
