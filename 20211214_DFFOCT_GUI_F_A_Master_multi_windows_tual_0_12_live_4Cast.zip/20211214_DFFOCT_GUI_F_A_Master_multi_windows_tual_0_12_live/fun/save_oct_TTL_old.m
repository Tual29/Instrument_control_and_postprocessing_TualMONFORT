function handles=save_oct_TTL(handles)

fds=zeros(100,2);
        
        
        for ii=1:100
            if ii<=handles.duty_cycle_TTL_save.Value
                fds(ii,1)=5;
            end
        end
        
        fds(:,2)=ones(100,1).*handles.piezo_voltage_dc.Value;
        
        fds=circshift(fds,handles.phase_shift.Value);
        
switch handles.mode_save.Value
    case 1
        %raw data
        %no piezo motion
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [20, 1]); 
    case 2
        % time DC removed
        %no piezo motion
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [20, 1]); 
    case 3
        %2-phases mode
        fds=repmat(fds, [2, 1]);
        
        for jj=1:2
            
            fds(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(handles.V_c_TTL.Value);

        end
        

        handles.TTL_output_save=repmat(fds, [20*5*3, 1]); %
    case 6
        %10-phases mode
%         handles.frames_acquired_fct_C_save.Value=handles.dot_pc_TTL.Value*handles.n_o_c_TTL.Value;
%         handles.frames_acquired_fct_C_save.String=num2str(handles.frames_acquired_fct_C_save.Value);
%         
%         fds=repmat(fds, [handles.dot_pc_TTL.Value*handles.n_o_c_TTL.Value, 1]);
% 
%         for ii=1:handles.n_o_c_TTL.Value
%             for jj=1:handles.dot_pc_TTL.Value
%                 
%                 fds(1+(jj-1)*100+(ii-1)*100*handles.dot_pc_TTL.Value:jj*100+(ii-1)*100*handles.dot_pc_TTL.Value,2)=ones(100,1).*(jj-1)*(handles.V_c_TTL.Value/handles.dot_pc_TTL.Value)+(ii-1)*handles.V_c_TTL.Value;
% 
%             end
%         end
%         
%  
%         handles.TTL_output_save=repmat(fds, [20, 1]);   %it seems that the cycle needs to be reppeated  many times in order to avoid the camera crashing...
        
        fds(:,2)=ones(100,1);
%         fds=repmat(fds, [2, 1]);

        handles.frames_acquired_fct_C_save.Value=5000;
        handles.frames_acquired_fct_C_save.String=num2str(handles.frames_acquired_fct_C_save.Value);
        
        fds=repmat(fds, [handles.frames_acquired_fct_C_save.Value, 1]);
        a=linspace(0,10,5000);

% 
        for ii=1:5000
            fds(1+100*(ii-1):100*ii,2)=a(1,ii);
        end
        
 
        handles.TTL_output_save=repmat(fds, [20, 1]);   %it seems that the cycle needs to be reppeated  many times in order to avoid the camera crashing...


    case 8
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [20, 1]); 
        
        
        

end

figure(123);plot(fds(:,1));hold on;plot(fds(:,2))
