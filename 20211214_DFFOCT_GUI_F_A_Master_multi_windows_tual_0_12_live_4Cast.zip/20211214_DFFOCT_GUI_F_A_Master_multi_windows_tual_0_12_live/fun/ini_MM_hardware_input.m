function handles=ini_MM_hardware_input(handles)


handles.delta_z.Value=1;
handles.delta_z.String=num2str(handles.delta_z.Value);
handles.delta_y.Value=1;
handles.delta_y.String=num2str(handles.delta_y.Value);
handles.delta_x.Value=1;
handles.delta_x.String=num2str(handles.delta_x.Value);


handles.absolute_z.Value=handles.mmc.getPosition();
handles.absolute_z.String=num2str(handles.absolute_z.Value);
handles.absolute_y.Value=handles.mmc.getYPosition();
handles.absolute_y.String=num2str(handles.absolute_y.Value);
handles.absolute_x.Value=handles.mmc.getXPosition();
handles.absolute_x.String=num2str(handles.absolute_x.Value);



handles.turret_epi_1.Value=1+str2double(handles.mmc.getProperty('Condenser turret','State'));
% handles.turret_epi_2.Visible=s;
handles.shutter_epi_1.Value=1+str2double(handles.mmc.getProperty('EpiShutter 1','State'));
% handles.shutter_epi_2.Visible=s;

handles.camera_port.Value=1+str2double(handles.mmc.getProperty('Light Path','State'));

handles.condenser_filter_wheel.Value=1+str2double(handles.mmc.getProperty('Condenser turret','State'));

handles.brightness_trans.Value=1+str2double(handles.mmc.getProperty('TransmittedIllumination 2','Brightness'));
% handles.brightness_trans.Value=0;

handles.aperature_trans.Value=1+str2double(handles.mmc.getProperty('Transmitted Aperture','DiameterAsPercent'));

handles.transmition_shutter.Value=1+str2double(handles.mmc.getProperty('DiaShutter','State'));


