function save_oct_parfeval_hsv(dffoct,Ht,St,Vt,CuSt,path,t,mode,name,fps,te)

writematrix([fps;te],[path '\' num2str(t) 'specs.txt']);

b=size(Ht,3);

switch mode
    case 1
        
        save([path '\' num2str(t) 'dffoct.mat'],'dffoct','-v7.3','-nocompression')
    case 2
        
        %check if the function can be called from fun in parfeval mode
        %in the meanwhile, I do not use the function
        mi=min(Ht(:));
        ma=max(Ht(:));
        writematrix([mi;ma],[path '\' num2str(t) 'Ht_min_max' name(1,7:end) '.txt']);
        
        mi=min(St(:));
        ma=max(St(:));
        writematrix([mi;ma],[path '\' num2str(t) 'St_min_max' name(1,7:end) '.txt']);
        
        mi=min(Vt(:));
        ma=max(Vt(:));
        writematrix([mi;ma],[path '\' num2str(t) 'Vt_min_max' name(1,7:end) '.txt']);
        
        mi=min(CuSt(:));
        ma=max(CuSt(:));
        writematrix([mi;ma],[path '\' num2str(t) 'CuSt_min_max' name(1,7:end) '.txt']);
        
        
        if b==1
        imwrite(dffoct,[path '\' 'dffoct' name(1,7:end) 't' num2str(t) '.tif'])
        imwrite(uint16(65535.*rescale(Ht)),[path '\' 'H' name(1,7:end) 't' num2str(t) '.tif'])
        imwrite(uint16(65535.*rescale(St)),[path '\' 'S' name(1,7:end) 't' num2str(t) '.tif'])
        imwrite(uint16(65535.*rescale(Vt)),[path '\' 'V' name(1,7:end) 't' num2str(t) '.tif'])
        imwrite(uint16(65535.*rescale(CuSt)),[path '\' 'CuS' name(1,7:end) 't' num2str(t) '.tif'])
        else
            Ht=rescale(Ht);
            for jj=1:b
            if jj==1
                imwrite(uint16(65536.*rescale(Ht(:,:,1))),[path '\' name(1,7:end) 't' num2str(t) '.tif'])
            else
                imwrite(uint16(65536.*rescale(Ht(:,:,jj))),[path '\' name(1,7:end) 't' num2str(t) '.tif'], 'writemode', 'append');
            end
            end
        end
end