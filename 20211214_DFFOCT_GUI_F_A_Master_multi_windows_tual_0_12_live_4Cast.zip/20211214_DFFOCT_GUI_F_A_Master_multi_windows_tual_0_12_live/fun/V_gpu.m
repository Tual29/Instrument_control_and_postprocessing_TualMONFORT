function V = V_gpu(im)



n_std = 50;     % Number of sample in the moving STD.
freq_min = 4;   % Minimum frequency to consider in Fourier domain.

s = size(im);
directMean = mean(im,[1 2]);

    im=single(im./directMean);





        for ii = 1:floor((s(3)-n_std)/16)

            im(:,:,ii) = std(im(:,:,(ii-1)*16+1:(ii-1)*16+n_std),[],3);
            
        end
        V = gather(mean(im,3));
        
   

end
