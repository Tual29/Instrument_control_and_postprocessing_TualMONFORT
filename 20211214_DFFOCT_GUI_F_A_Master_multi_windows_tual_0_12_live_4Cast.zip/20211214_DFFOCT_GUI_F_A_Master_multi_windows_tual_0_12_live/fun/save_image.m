function save_image(obj,event,handles)
1

global T

% c = clock;
% dd=([handles.path.String '\' num2str(c(1)) '_' num2str(c(2)) '_' num2str(c(3)) '_' num2str(c(4)) '_' num2str(c(5)) '_' num2str(T)]);
% mkdir(dd)

T=T+1;

Image=squeeze(getdata(handles.vid_cam_oct));
2
switch handles.mode_save.Value
    
    case 1
        saveGUI(handles,Image,'Raw')
%        save([dd '\' num2str(T) 'Raw.mat'],'Image')
       
%        handles.save_image.BackgroundColor=[0 1 0];
    
    case 3
        
        saveGUI(handles,mean(Image(:,:,1:2:end)-Image(:,:,2:2:end),3),'_2phase');
        
    case 6
        dd=handles.dd;
        parfeval(@save_parfeval, 0,Image,dd,T);
3
%         saveGUI(handles,Image,'Raw')
        
%         [Iampl, Ephase]=multi_phases(gpuArray(single(Image)),handles.mode_multi_phase.Value);
% 
%         set(handles.raw,'CData',double(gather(Iampl)));
%         set(handles.phase,'CData',double(gather(Ephase)));
    case 9
        V = V_gpu(single(gpuArray(Image)));
end
%stop(handles.vid_cam_oct)