function a=get_microscope_plus_XY_stage_handles
g_m=findobj('tag','microscope_plus_XY_stage');
a=guidata(g_m);