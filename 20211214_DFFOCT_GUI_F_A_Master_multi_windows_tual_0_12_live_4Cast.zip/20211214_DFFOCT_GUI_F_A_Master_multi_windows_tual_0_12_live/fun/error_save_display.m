function error_save_display(obj,event,handles)
stop(handles.d)
stop(handles.vid_cam_oct)
    
    queueOutputData(handles.d,handles.TTL_output);
    startBackground(handles.d);
    pause(0.1)
    
    set(handles.vid_cam_oct, 'FramesPerTrigger', handles.frames_acquired_fct_C_save.Value,'TriggerRepeat',handles.num_of_trig.Value, 'LoggingMode', 'memory');
    handles.vid_cam_oct.FramesAcquiredFcnCount=handles.frames_acquired_fct_C_save.Value;
    handles.vid_cam_oct.FramesAcquiredFcn={'save_image',handles};
    handles.vid_cam_oct.ErrorFcn = {'error_save_display',handles};
    start(handles.vid_cam_oct)
