function live_display(obj,event,handles)

Image=squeeze(getdata(handles.master.vid_cam_oct));

if handles.live_oct_waste.Value>0   
    Image=Image(:,:,1:end-handles.live_oct_waste.Value);
end
if handles.live_oct_binning.Value>1  
    if handles.live_oct_mode.Value==3
    else
    Image=binning_data_single(Image,handles.live_oct_binning.Value);
    end
end

[s1 s2 s3]=size(Image);

switch handles.live_oct_mode.Value
    
    case 1
        
        if handles.live_oct_accu.Value==1
            set(handles.master.gui1Handles.one,'CData',Image(:,:,1));
        else
            set(handles.master.gui1Handles.one,'CData',mean(single(Image(:,:,1:handles.live_oct_accu.Value)),3,'native'));
        end

        a=single(max(Image(:)));
        b = mean(maxk(Image(:),1000));


        set(handles.master.gui1Handles.sat1,'String',num2str(100*((a-0)/(2048-0)),3))
        set(handles.master.gui1Handles.sat1_glob,'String',num2str(100*((b-0)/(2048-0)),3))    
  
    case 3
        
        
        
        if s3>=2
           
            pas=2;
            tr=floor(s3/pas);
            
            if handles.live_oct_accu.Value==1
                set(handles.master.gui1Handles.one,'CData',Image(:,:,1));
            else
                set(handles.master.gui1Handles.one,'CData',...
                    mean(single(Image(:,:,1:handles.live_oct_accu.Value)),3,'native'));
            end
            

%         co=min([handles.accu_live.Value,s(3)],[],1);
   
        
        a=single(max(Image(:)));
        b = mean(maxk(Image(:),1000));
        
        set(handles.master.gui1Handles.sat1,'String',num2str(100*((a-0)/(2048-0)),3))
        set(handles.master.gui1Handles.sat1_glob,'String',num2str(100*((b-0)/(2048-0)),3))

        if handles.live_oct_accu.Value==1
            
            if handles.live_oct_binning.Value==1
                
            A=abs(single(Image(:,:,1))-single(Image(:,:,2)));
            set(handles.master.gui2Handles.two,'CData',...
                A);
            else

                
                A=abs(mean(single(Image(:,:,1:handles.live_oct_frames_acquired_fct_C.Value)),3)-mean(single(Image(:,:,handles.live_oct_frames_acquired_fct_C.Value+1:end)),3));
            set(handles.master.gui2Handles.two,'CData',...
                A);
            end
        else
            %A=reshape(Image(:,:,1:pas*tr),s(1)*s(2),pas,[]);
            A=abs(mean(int16(A(:,:,1:2:pas*tr))-int16(A(:,:,2)),3,'native'));
            set(handles.master.gui2Handles.two,'CData',...
                reshape(mean(single(A(:,1,:))-single(A(:,2,:)),3,'native'),s(1),s(2)));
        end
        

        a=single(max(A(:)));
        b=single(min(A(:)));

        set(handles.master.gui2Handles.sat2,'String',num2str(100*((a-b)/(2048-b)),3))
        
        a = mean(maxk(A(:),1000));
        
        set(handles.master.gui2Handles.sat2_glob,'String',num2str(100*((a-b)/(2048-b)),3))
        
        end%condition on frame >=2


        
    case 6
        
        
%         [Iampl, Ephase]=multi_phases(gpuArray(single(Image)),handles.mode_multi_phase.Value);
        [Iampl, Ephase]=multi_phases((single(Image)),3);

        set(handles.master.gui1Handles.one,'CData',single(gather(Iampl)));
        set(handles.master.gui2Handles.two,'CData',single(gather(Ephase)));
    case 7
        [Ht,St,Vt,handles] = HSV_gpu_J_tualmodified_1(Image,handles);
        
        set(handles.gui1Handles.one,'CData',Ht);
        
        set(handles.gui2Handles.two,'CData',St);
        
        set(handles.gui3Handles.three,'CData',Vt);
    case 8
        ImR=binning_data_uint16(Image,2);
    case 9

        V = V_gpu(single(gpuArray(Image)));
        set(handles.gui1Handles.one,'CData',V);
        1

       
       
       
end