function a=get_oct_motor_ref_handles
g_m=findobj('tag','oct_motor_ref');
a=guidata(g_m);