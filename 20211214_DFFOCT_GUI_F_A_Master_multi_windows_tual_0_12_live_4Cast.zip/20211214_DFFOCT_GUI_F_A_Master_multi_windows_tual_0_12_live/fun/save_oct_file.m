function save_oct_file(handles,I,name)
global T
dd=handles.save_oct_path.String;
if handles.save_oct_format.Value==1
   
    save([handles.dd '\' num2str(T) name '.mat'],'I','-v7.3','-nocompression')
elseif handles.save_oct_format.Value==2
    imwrite(im2uint16(rescale(I,0,1)),[handles.dd '\' num2str(T) name '.tif'])
end