function handles=ini_stack(handles)

handles.stack_start.String='0';
handles.stack_start.Value=str2double(handles.stack_start.String);

handles.stack_step.String='1';
handles.stack_step.Value=str2double(handles.stack_step.String);

handles.stack_end.String='10';
handles.stack_end.Value=str2double(handles.stack_end.String);

handles.z_steps=linspace(handles.stack_start.Value,handles.stack_end.Value,handles.stack_step.Value);
handles.nz_steps=length(handles.z_steps);