function handles=live_oct_TTL(handles)

master=get_master_handles;

Ns=handles.live_oct_frame_per_second.Value*100;

if master.checkbox_live_oct.Value==1
    
fds=zeros(100,2);       
        
        for ii=1:100
            if ii<=handles.live_oct_duty_cycle_TTL.Value
                fds(ii,1)=5;
            end
        end
        
        fds(:,2)=ones(100,1).*master.piezo_voltage_dc.Value;
        
%         fds=circshift(fds,master.phase_shift.Value);
        
switch handles.live_oct_mode.Value
    case 1
        %raw data
        %no piezo motion
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_live=repmat(fds, [ceil(Ns./(10*3)), 1]); 
    case 2
        % time DC removed
        %no piezo motion
        

        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_live=repmat(fds, [ceil(Ns./(10*3)), 1]); 

        
    case 3
        %2-phases mode
        
         fdss=fds;
        
        t_p_b=((handles.live_oct_expo_time.Value)*(100-handles.live_oct_duty_cycle_TTL.Value)/(handles.live_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.live_oct_duty_cycle_TTL.Value;
        
        if t_p_b<t_b_min
            as=round((100-handles.live_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,2)];
            ns=round((100-handles.live_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.live_oct_duty_cycle_TTL.Value>50
%             gfd
        end
        
        fdss=circshift(fdss,ceil(ns/2));
        hgf=repmat(fdss, [2*handles.live_oct_binning.Value, 1]);
        
        fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(jj-1)*fer:jj*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
    
    
            figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))
    
    
     handles.TTL_output_live=repmat(hgf,...
                [ceil(Ns./(2.*handles.live_oct_binning.Value)), 1]);
    
%     
%         fds=repmat(fds, [2, 1]);
%         
%         for jj=1:2
%             
%             fds(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);
% 
%         end
%         
%         if handles.live_oct_binning.Value>1
%             fds=repelem(fds,handles.live_oct_binning.Value,1);
%             handles.TTL_output_live=repmat(fds,...
%                 [ceil(Ns./(2*handles.live_oct_binning.Value)), 1]);
%         else
%             handles.TTL_output_live=repmat(fds,...
%                 [ceil(Ns/2), 1]); %
%         end
%         
    case 6
        %multi-phases mode
        handles.live_oct_frames_acquired_fct_C.Value=master.dot_pc_TTL.Value*master.n_o_c_TTL.Value...
            *handles.live_oct_binning.Value;
        handles.live_oct_frames_acquired_fct_C.String=num2str(handles.live_oct_frames_acquired_fct_C.Value);
        
        fds=repmat(fds, [master.dot_pc_TTL.Value*master.n_o_c_TTL.Value, 1]);

        for ii=1:master.n_o_c_TTL.Value
            for jj=1:master.dot_pc_TTL.Value
                
                fds(1+(jj-1)*100+(ii-1)*100*master.dot_pc_TTL.Value:jj*100+(ii-1)*100*master.dot_pc_TTL.Value,2)=...
                    ones(100,1).*(jj-1)*(master.V_c_TTL.Value/master.dot_pc_TTL.Value)+(ii-1)*master.V_c_TTL.Value;

            end
        end
        
        if handles.live_oct_binning.Value==1
        handles.TTL_output_live=repmat(fds, [20, 1]);   %it seems that the cycle needs to be reppeated  many times in order to avoid the camera crashing...
        else           
            fds1=repmat(fds,[handles.live_oct_binning.Value]);
            fds1(:,2)=repelem(fds(:,2),handles.live_oct_binning.Value);
            fds=fds1;
            handles.TTL_output_live=repmat(fds,...
                [20*5*3./(handles.live_oct_binning.Value), 1]);
        end
        
    case 9
        %V
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_live=repmat(fds, [ceil(Ns./(10*3)), 1]); 

end

figure(123);plot(fds(:,1));hold on;plot(fds(:,2))
end
