function save_image_32bit(I,name)
mi=min(I(:));
ma=max(I(:));
writematrix([mi;ma],'min_max.txt');

data = uint32(4294967295.*rescale(I));
t = Tiff([name '.tif'],'w');
% Setup tags
% Lots of info here:
% http://www.mathworks.com/help/matlab/ref/tiffclass.html
tagstruct.ImageLength     = size(I,1);
tagstruct.ImageWidth      = size(I,2);
tagstruct.Photometric     = Tiff.Photometric.MinIsBlack;
tagstruct.BitsPerSample   = 32;
tagstruct.SamplesPerPixel = 1;
tagstruct.RowsPerStrip    = 16;
tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
tagstruct.Software        = 'MATLAB';
t.setTag(tagstruct)
t.write(I);
t.close();