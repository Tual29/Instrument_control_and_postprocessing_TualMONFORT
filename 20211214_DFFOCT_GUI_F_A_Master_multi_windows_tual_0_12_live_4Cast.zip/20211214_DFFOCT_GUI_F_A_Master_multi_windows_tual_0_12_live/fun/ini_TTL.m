function handles=ini_TTL(handles)

handles.dot_pc_TTL.Value=10;
handles.dot_pc_TTL.String=num2str(handles.dot_pc_TTL.Value);

handles.n_o_c_TTL.Value=3;%number of points per cycle // samples per cycle
handles.n_o_c_TTL.String=num2str(handles.n_o_c_TTL.Value);

handles.V_c_TTL.Value=3.5;%Volt per 2pi // see piezo information
handles.V_c_TTL.String=num2str(handles.V_c_TTL.Value);

handles.phase_shift.String='30';%phase shift in percentage of 2pi
handles.phase_shift.Value=str2double(handles.phase_shift.String);

handles.dot_pc_TTL.String='10';
handles.dot_pc_TTL.Value=str2double(handles.dot_pc_TTL.String);

handles.n_o_c_TTL.String='3';
handles.n_o_c_TTL.Value=str2double(handles.n_o_c_TTL.String);