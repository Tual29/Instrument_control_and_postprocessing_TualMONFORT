function handles=ini_daq(handles)

handles.d=daq.createSession('ni');

handles.d.IsContinuous = true;
handles.cam_oct_TTL = addAnalogOutputChannel(handles.d,'cDAQ1Mod2','ao0','Voltage');
handles.cam_oct_piezo=addAnalogOutputChannel(handles.d,'cDAQ1Mod2','ao1','Voltage');
handles.d.Rate=1000;
handles.d.NotifyWhenDataAvailableExceeds=uint64(100000);
handles.d.IsNotifyWhenDataAvailableExceedsAuto=0;
handles.d.NotifyWhenScansQueuedBelow=uint64(100000);
handles.d.IsNotifyWhenScansQueuedBelowAuto=0;
handles.d.ExternalTriggerTimeout=100000;