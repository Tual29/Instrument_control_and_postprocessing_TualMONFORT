function mode_display_cali(obj,event,handles)
1
Image=(single(squeeze(getdata(handles.vid_cam_oct))));
2
[nx ny nz]=size(Image);
%Ef=fft(Image((nx/2)-10:(nx/2)+10,(ny/2)-10:(ny/2)+10,:),nz,3);
% figure(123);plot(squeeze(mean(mean(abs(Ef).^2))));
% figure(123);plot(squeeze(((abs(Ef(1,1,:)).^2))));
a=cd;
 save([a '\' 'Raw.mat'],'Image')