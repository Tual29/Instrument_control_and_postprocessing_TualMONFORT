function handles=save_oct_TTL(handles)

 master=get_master_handles;
 
 Ns=handles.save_oct_frame_per_second.Value*100;%number of samples per seconds; still not perfectly clear how many seconds should be preloaded

if master.checkbox_save_oct.Value==1
    
    
   

fds=zeros(100,2);       
        
        for ii=1:100
            if ii<=handles.save_oct_duty_cycle_TTL.Value
                fds(ii,1)=5;
            end
        end
        
        fds(:,2)=ones(100,1).*master.piezo_voltage_dc.Value;
        
%         fds=circshift(fds,master.phase_shift.Value);
        
        

        
switch handles.save_oct_mode.Value
    case 1
        %raw data
        %no piezo motion
        fds=repmat(fds, [10*4, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); %fds is set as an intermedaire step to diagnose the output
    case 2
        % time DC removed
        %no piezo motion
        

        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 

        
    case 3
        %2-phases mode
        fds=repmat(fds, [2, 1]);
        
        for jj=1:2
            
            fds(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);

        end
        
        if handles.save_oct_binning.Value>1
            fds=repelem(fds,handles.save_oct_binning.Value,1);
            handles.TTL_output_save=repmat(fds,...
                [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
        else
            handles.TTL_output_save=repmat(fds,...
                [Ns/2, 1]); %
        end
        
    case 6
        %multi-phases mode
        handles.save_oct_frames_acquired_fct_C.Value=master.dot_pc_TTL.Value*master.n_o_c_TTL.Value...
            *handles.save_oct_binning.Value;
        handles.save_oct_frames_acquired_fct_C.String=num2str(handles.save_oct_frames_acquired_fct_C.Value);
        
        fds=repmat(fds, [master.dot_pc_TTL.Value*master.n_o_c_TTL.Value, 1]);

        for ii=1:master.n_o_c_TTL.Value
            for jj=1:master.dot_pc_TTL.Value
                
                fds(1+(jj-1)*100+(ii-1)*100*master.dot_pc_TTL.Value:jj*100+(ii-1)*100*master.dot_pc_TTL.Value,2)=...
                    ones(100,1).*(jj-1)*(master.V_c_TTL.Value/master.dot_pc_TTL.Value)+(ii-1)*master.V_c_TTL.Value;

            end
        end
        
        if handles.save_oct_binning.Value==1
        handles.TTL_output_save=repmat(fds, [20, 1]);   %it seems that the cycle needs to be reppeated  many times in order to avoid the camera crashing...
        else           
            fds1=repmat(fds,[handles.save_oct_binning.Value]);
            fds1(:,2)=repelem(fds(:,2),handles.save_oct_binning.Value);
            fds=fds1;
            handles.TTL_output_save=repmat(fds,...
                [20*5*3./(handles.save_oct_binning.Value), 1]);
        end
    case 7
        %dffoct
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
    case 8 %dffoct + 2phase
     
        fdss=fds;
        
        t_p_b=((handles.save_oct_expo_time.Value)*(100-handles.save_oct_duty_cycle_TTL.Value)/(handles.save_oct_duty_cycle_TTL.Value));
        t_b_min=5;
        ns=100-handles.save_oct_duty_cycle_TTL.Value;
        if t_p_b<t_b_min

            as=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min-t_p_b)/t_p_b));
            fdss=[fdss;zeros(as,2)];
            ns=round((100-handles.save_oct_duty_cycle_TTL.Value).*((t_b_min)/t_p_b));
        elseif handles.save_oct_duty_cycle_TTL.Value>50
%             gfd
        end
        
        
%                 figure(234)
%     plot(fdss(:,1))
%     hold on
%     plot(fdss(:,2))
        
%            tot2P=2.*handles.save_oct_accu.Value.*handles.save_oct_binning.Value;
%            totD=handles.save_oct_frames_acquired_fct_C.Value.*handles.save_oct_accu.Value.*handles.save_oct_binning.Value;
%            totW=handles.save_oct_waste.Value;
%            tot=((2+handles.save_oct_frames_acquired_fct_C.Value).*...
%         handles.save_oct_accu.Value.*...
%         handles.save_oct_binning.Value)+handles.save_oct_waste.Value;

        fdss=circshift(fdss,ceil(ns/2));
%         hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);
        
%         for jj=1:2
%             
%             fdss(1+(jj-1)*100:jj*100,2)=ones(100,1).*(jj-1)*(master.V_c_TTL.Value);
% 
%         end
     
    hgf=repmat(fdss, [2*handles.save_oct_binning.Value, 1]);  
    
    fer=ceil(size(hgf,1)./2);
    
    for jj=1:2%use the initial loop for cleaner reading
            
            hgf(1+(jj-1)*fer:jj*fer...
                ,2)=ones(fer,1).*(jj-1)*(master.V_c_TTL.Value);

    end   
    
    
        figure(234)
    plot(hgf(:,1))
    hold on
    plot(hgf(:,2))


    
%careful: if duty> 50% it does not work for the 2 phases
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %2 phase limited bandwidth
%     if ((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value)))<20%20 is an arbitary value representing enabling to wait for the piezo to reach its final position before logging the data
%         r=ceil(20/((handles.save_oct_expo_time.Value)*(1-0.01*(handles.save_oct_duty_cycle_TTL.Value))));
%         hgf=[hgf(1:100*handles.save_oct_binning.Value,:);zeros(handles.save_oct_duty_cycle_TTL.Value*r,2);hgf(1+100*handles.save_oct_binning.Value:end,:)];
%     end
    
    handles.TTL_output_save=repmat(hgf,...
                [ceil(Ns./(2.*handles.save_oct_binning.Value)), 1]);
            
            fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
  
% lol1=handles.TTL_output_save;
% lol2=handles.TTL_output_save_2;


        
        
%     figure(234)
%     plot(lol1(:,1))
%     hold on
%     plot(lol1(:,2))
%      figure(456)
%     plot(lol2(:,1))
%      hold on
%     plot(lol2(:,2))
    
%     hgf=repmat(hgf, [handles.save_oct_accu.Value, 1]); 
%     fds=repmat(fds, [totD+totW, 1]); 
%     
%     fds=[hgf;fds];
%     
%     handles.TTL_output_save=repmat(fds, [ceil(Ns./(tot)), 1]); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
         
    case 9
        %V
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
        
    case 13
        
       fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 
        
    case 14
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 
    case 15
        fds=repmat(fds, [10*3, 1]);
        handles.TTL_output_save_2=repmat(fds, [ceil(Ns./(10*3)), 1]); 

        
        
         
        
end

figure(123);plot(fds(:,1));hold on;plot(fds(:,2))
end
