function save_parfeval(I,path,t)


b=size(I,3);
% a=rand(10,10,10);
% save('test.mat','a','-v7.3','-nocompression')
save([path num2str(t) 'test1.mat'],'b','-v7.3','-nocompression')
save([path num2str(t) 'test.mat'],'I','-v7.3','-nocompression')