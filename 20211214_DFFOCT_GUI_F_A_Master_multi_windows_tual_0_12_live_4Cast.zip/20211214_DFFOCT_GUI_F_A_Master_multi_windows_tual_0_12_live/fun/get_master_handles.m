function a=get_master_handles
g_m=findobj('tag','gui_master_ts');
a=guidata(g_m);