function handles=ini_camera_oct(handles)

handles.vid_cam_oct = videoinput('bitflow', 1, 'Default@Adimec-Quartz-2A750-Mono triggered.bfml');
handles.src = getselectedsource(handles.vid_cam_oct);
handles.src.BuffersToUse = 100;
set(handles.vid_cam_oct,'Timeout',10000);

handles.res_x=1440;
handles.res_y=1440;

handles.oct_array_digi_size.Value=handles.res_y;
handles.oct_array_digi_size.String=num2str(handles.oct_array_digi_size.Value);