function handles = delay_auto_adjustement(handles)


%get the acquisiion mode;

acq_mode=handles.save_oct_mode.Value;
% you need to define a handles.Xc,handles.Yc (center of the sample imaged)
                        xi=handles.microscope.mmc.getXPosition();
                        yi=handles.microscope.mmc.getYPosition();
                        
                        Steps_towards_xf=linspace(xi,handles.Xc,round(abs(xi-(handles.Xc)))/20);
                        if length(Steps_towards_xf)>0
                            
                        for xxx=1:length(Steps_towards_xf)
                        handles.microscope.mmc.setXYPosition(Steps_towards_xf(1,xxx),yi);
                        handles.microscope.mmc.waitForSystem();
                        end
                        end
                        
                        
                        Steps_towards_yf=linspace(yi,handles.Yc,round(abs(yi-(handles.Yc)))/20);
                        if length(Steps_towards_yf)>0
                        for yyy=1:length(Steps_towards_yf)
                        handles.microscope.mmc.setXYPosition(handles.Xc,Steps_towards_yf(1,yyy));
                        handles.microscope.mmc.waitForSystem();
                        end
                        end
                        
handles.save_oct_mode.Value= 3;% 2phase mode    

handles=save_oct_TTL(handles);

handles.master.d.IsContinuous=true;
            

            queueOutputData(handles.master.d,handles.TTL_output_save);

            
            startBackground(handles.master.d);
            pause(0.1)


            handles.part=1;