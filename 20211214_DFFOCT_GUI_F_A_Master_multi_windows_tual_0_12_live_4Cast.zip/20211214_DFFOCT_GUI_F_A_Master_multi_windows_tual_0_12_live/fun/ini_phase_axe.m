function handles=ini_phase_axe(handles)

handles.min_range_phase.Value=-pi;
handles.min_range_phase.String=num2str(handles.min_range_phase.Value);

handles.max_range_phase.Value=pi;
handles.max_range_phase.String=num2str(handles.max_range_phase.Value);

hold off
axes(handles.axes_phase)
handles.phase=imagesc(1:1440,...
    1:1440,...
    zeros(1440,1440),...
    'Parent',handles.axes_phase);
caxis([handles.min_range_phase.Value handles.max_range_phase.Value]);colorbar(handles.axes_phase);colormap('jet');axis off

hold off