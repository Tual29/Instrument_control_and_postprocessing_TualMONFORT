function [Iampl, Ephase]=multi_phases(Image,pf)
[nx ny nz]=size(Image);
Ef=fft(Image,nz,3);
Ephase=angle(Ef(:,:,pf));
Iampl=(abs(Ef(:,:,pf))./sqrt(nz)).^2;