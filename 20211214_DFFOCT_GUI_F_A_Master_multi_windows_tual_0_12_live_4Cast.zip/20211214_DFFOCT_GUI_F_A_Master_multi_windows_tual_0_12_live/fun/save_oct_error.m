function save_oct_error(obj,event,handles)
stop(handles.master.d)
stop(handles.master.vid_cam_oct)
    flushdata(handles.master.vid_cam_oct)
    queueOutputData(handles.master.d,handles.TTL_output_save);
    startBackground(handles.master.d);
    pause(0.1)
    
    
    if handles.save_oct_mode.Value==13
    set(handles.master.vid_cam_oct, 'FramesPerTrigger', Inf,'TriggerRepeat',handles.save_oct_num_of_trig.Value, 'LoggingMode', 'memory');
    handles.master.vid_cam_oct.FramesAcquiredFcnCount=handles.save_oct_frames_acquired_fct_C.Value;   
    handles.master.vid_cam_oct.FramesAcquiredFcn={'save_oct_processing',handles};
    handles.master.vid_cam_oct.ErrorFcn = {'save_oct_error',handles};
    start(handles.master.vid_cam_oct)   
    else
    set(handles.vid_cam_oct, 'FramesPerTrigger', handles.frames_acquired_fct_C_save.Value,'TriggerRepeat',handles.num_of_trig.Value, 'LoggingMode', 'memory');
    handles.vid_cam_oct.FramesAcquiredFcnCount=handles.frames_acquired_fct_C_save.Value;
    handles.vid_cam_oct.FramesAcquiredFcn={'save_image',handles};
    handles.vid_cam_oct.ErrorFcn = {'error_save_display',handles};
    start(handles.vid_cam_oct)
    end
end
