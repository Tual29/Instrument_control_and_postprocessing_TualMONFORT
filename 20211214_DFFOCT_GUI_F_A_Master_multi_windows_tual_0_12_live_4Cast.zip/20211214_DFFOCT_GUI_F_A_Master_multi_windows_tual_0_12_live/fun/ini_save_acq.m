function handles=ini_save_acq(handles)

handles.save_oct_frame_per_second.Value=100;
handles.save_oct_frame_per_second.String=num2str(handles.save_oct_frame_per_second.Value);


handles.save_oct_expo_time.Value=9;
handles.save_oct_expo_time.String=num2str(handles.save_oct_expo_time.Value);

handles.save_oct_frames_acquired_fct_C.Value=1;
handles.save_oct_frames_acquired_fct_C.String=num2str(handles.save_oct_frames_acquired_fct_C.Value);

handles.save_oct_waste.Value=0;
handles.save_oct_waste.String=num2str(handles.save_oct_waste.Value);

handles.save_oct_binning.Value=1;
handles.save_oct_binning.String=num2str(handles.save_oct_binning.Value);

handles.save_oct_accu.Value=1;
handles.save_oct_accu.String=num2str(handles.save_oct_accu.Value);

handles.save_oct_duty_cycle_TTL.String='50';
handles.save_oct_duty_cycle_TTL.Value=str2double(handles.save_oct_duty_cycle_TTL.String);

handles.save_oct_num_of_trig.Value=0;
handles.save_oct_num_of_trig.String=num2str(handles.save_oct_num_of_trig.Value);

handles.mode_save.Value=1;

handles.saving_format.Value=2;

handles.save_oct_path.String='C:\';