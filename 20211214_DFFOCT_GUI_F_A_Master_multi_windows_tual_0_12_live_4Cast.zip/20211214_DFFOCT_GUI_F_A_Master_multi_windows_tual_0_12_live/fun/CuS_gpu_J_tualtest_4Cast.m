function [CuS,handles] = CuS_gpu_J_tualtest_4Cast(im,handles,Siz)
tic
s = size(im);

whos im
if size(im,3)==0 
elseif s(3)<50
else
if s(3)==Siz
elseif s(3)< Siz
   im=im(:,:,1:end-rem(Siz,16)); 
elseif s(3)>Siz
    im=im(:,:,1:Siz);
end
s = size(im);


% freq_min = round(s(3).*0.03);   % Minimum frequency to consider in Fourier domain.

% Hard coded parameters
n_std = 50.*handles.save_oct_binning.Value;     % Number of sample in the moving STD.
freq_min = 4;   % Minimum frequency to consider in Fourier domain.

% We normalize each frame to remove sensor frame to frame instabilities.
im = single(squeeze(im));


% directMean = (mean(mean(im,1),2));
directMean = (mean(im,[1 2]));


%     im=(im./directMean);
    im=(im./directMean)-1;

whos im

        imGPU = gpuArray(im);
%        V = zeros(s(1),s(2),s(3)/16,'single','gpuArray');
        CuS = zeros(s(1),s(2),ceil(s(3)/16),'single','gpuArray');
%         whos V


        for i = 1:floor((s(3)-n_std)/16)
%             a=std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
%             whos a
           % V(:,:,i) = std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
            CuS(:,:,i) = max(abs(cumsum(mean(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)-imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)),[],3);
            
        end
       % V = gather(mean(V,3));
        
%         CuS = zeros(s(1),s(2),s(3)/16,'single','gpuArray');


%         for i = 1:floor((s(3)-n_std)/16)
% %             a=std(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),[],3);
% %             whos a
%             CuS(:,:,i) = max(abs(cumsum(mean(imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)-imGPU(:,:,(i-1)*16+1:(i-1)*16+n_std),3)),[],3);
%             
%         end
        CuS = gather(max(CuS,[],3));
end
        
end