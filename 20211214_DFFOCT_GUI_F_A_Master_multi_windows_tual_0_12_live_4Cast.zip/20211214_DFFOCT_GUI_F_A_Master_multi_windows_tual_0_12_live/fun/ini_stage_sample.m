function handles=ini_stage_sample(handles)    


handles.delta_z.String='0';
handles.motors.port = serial('com1','BaudRate',9600);
fopen(handles.motors.port);
handles.motors.protocol=Zaber.Protocol.detect(handles.motors.port);
handles.motors.sample = Zaber.BinaryDevice.initialize(handles.motors.protocol, 2);