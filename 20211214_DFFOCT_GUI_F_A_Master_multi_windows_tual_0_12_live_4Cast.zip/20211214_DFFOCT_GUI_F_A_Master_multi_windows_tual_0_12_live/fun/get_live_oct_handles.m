function a=get_live_oct_handles
g_m=findobj('tag','live_oct_win');
a=guidata(g_m);