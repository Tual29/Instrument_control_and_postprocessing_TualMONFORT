function handles=three_axe(handles)
axes(handles.axes_three)
caxis([handles.min_range_three.Value handles.max_range_three.Value])
hold off