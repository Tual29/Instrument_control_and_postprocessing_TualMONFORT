function handles=DC1_image(handles)



Image=squeeze(getdata(handles.vid_cam_oct));
Image=mean(Image,3);
handles.DC1_image=Image;

set(handles.raw,'CData',Image);

stop(handles.vid_cam_oct)