function tot=save_Nb_frames_tot(handles)

% cc=handles.save_oct_mode.Value;
% cc

if handles.save_oct_mode.Value==8
%     tot=((2+handles.save_oct_frames_acquired_fct_C.Value).*...
%         handles.save_oct_accu.Value.*...
%         handles.save_oct_binning.Value)+handles.save_oct_waste.Value;
    
    tot(1,1)=2*handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        +handles.save_oct_waste.Value;
    tot(1,2)=handles.save_oct_accu.Value.*handles.save_oct_binning.Value...
        .*handles.save_oct_frames_acquired_fct_C.Value;
elseif handles.save_oct_mode.Value==13 || handles.save_oct_mode.Value==14 || handles.save_oct_mode.Value==15
    
    tot=Inf;
else
    tot=((handles.save_oct_frames_acquired_fct_C.Value).*...
        handles.save_oct_accu.Value.*...
        handles.save_oct_binning.Value)+handles.save_oct_waste.Value;
end