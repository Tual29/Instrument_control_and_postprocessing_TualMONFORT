function h=check_live(handles)
h=0;
if handles.live_oct_mode.Value==3
    if handles.live_oct_frames_acquired_fct_C.Value<2*handles.live_oct_binning.Value...
            *handles.live_oct_accu.Value
        f = msgbox('Invalid Values', 'Error','error');
        h=1;
    end
end
        