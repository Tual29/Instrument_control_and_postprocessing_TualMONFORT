function handles=stop_everything_R(handles)
stop(handles.d)
stop(handles.vid_cam_oct)

if handles.checkbox_live_oct.Value==1
a=get_live_oct_handles;
a.live_oct_pushbutton.BackgroundColor=[0 1 0];
end
if handles.checkbox_save_oct.Value==1
a=get_save_oct_handles;
a.save_oct_pushbutton.BackgroundColor=[0 1 0];
end