function handles=stop_everything_sub(handles)
master=get_master_handles;

stop(master.d)
stop(master.vid_cam_oct)

if master.checkbox_live_oct.Value==1
loh=get_live_oct_handles;
loh.live_oct_pushbutton.BackgroundColor=[0 1 0];
end
if master.checkbox_save_oct.Value==1
soh=get_save_oct_handles;
soh.save_oct_pushbutton.BackgroundColor=[0 1 0];
end