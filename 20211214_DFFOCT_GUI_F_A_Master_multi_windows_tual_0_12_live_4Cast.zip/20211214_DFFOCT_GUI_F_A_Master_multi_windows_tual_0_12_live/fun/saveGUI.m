function saveGUI(handles,I,name)
global T
dd=handles.path.String;
if handles.saving_format.Value==1
   5
    save([handles.dd '\' num2str(T) name '.mat'],'I','-v7.3','-nocompression')
elseif handles.saving_format.Value==2
    imwrite(im2uint16(rescale(I,0,1)),[handles.dd '\' num2str(T) name '.tif'])
end


6