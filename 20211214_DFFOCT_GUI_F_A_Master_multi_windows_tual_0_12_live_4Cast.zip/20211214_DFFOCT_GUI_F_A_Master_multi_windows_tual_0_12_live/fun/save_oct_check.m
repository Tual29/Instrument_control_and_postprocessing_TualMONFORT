function h=save_oct_check(handles)
h=0;
if handles.save_oct_mode.Value==3
    if handles.save_oct_frames_acquired_fct_C.Value<2*handles.save_oct_binning.Value...
            *handles.save_oct_accu.Value
        f = msgbox('save_oct_frames_acquired_fct_C.Value too small', 'Error','error');
        h=1;
    end
end
        