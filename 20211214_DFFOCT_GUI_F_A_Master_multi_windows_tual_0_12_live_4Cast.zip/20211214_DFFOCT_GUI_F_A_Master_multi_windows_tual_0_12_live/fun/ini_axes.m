function handles=ini_axes(handles)

Rx=handles.res_x;
Ry=handles.oct_array_digi_size.Value;

win1
gui_one = findobj(allchild(0), 'flat', 'tag', 'win1');   % [EDITED]
handles.gui1Handles = guidata(gui_one);
set(handles.gui1Handles.one, 'CData', 1000*rand(Ry,Rx))


win2
gui_two = findobj(allchild(0), 'flat', 'tag', 'win2');   % [EDITED]
handles.gui2Handles=guidata(gui_two);
set(handles.gui2Handles.two, 'CData', 1000*rand(Ry,Rx))
% handles.gui2Handles = guidata(gui_two);
% set(handles.gui1Handles.two, 'CData', 1000*rand(1440,1440))


win3
gui_three = findobj(allchild(0), 'flat', 'tag', 'win3');   % [EDITED]
handles.gui3Handles=guidata(gui_three);
set(handles.gui3Handles.three, 'CData', 1000*rand(Ry,Rx))