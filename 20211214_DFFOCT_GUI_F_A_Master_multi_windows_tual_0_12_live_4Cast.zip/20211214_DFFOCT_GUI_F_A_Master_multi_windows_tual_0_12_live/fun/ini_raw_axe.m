function handles=ini_raw_axe(handles)

handles.min_range_raw.Value=0;
handles.min_range_raw.String=num2str(handles.min_range_raw.Value);

handles.max_range_raw.Value=2048;
handles.max_range_raw.String=num2str(handles.max_range_raw.Value);


hold off

axes(handles.axes_raw)
handles.raw=imagesc(1:1440,...
    1:1440,...
    zeros(1440,1440),...
    'Parent',handles.axes_raw);
caxis([handles.min_range_raw.Value handles.max_range_raw.Value]);colorbar;colormap('jet');axis off
hold off
