function [gui, mmc, acq]=ini_MM_connect(current_directory_path)


cd 'C:\Micro-Manager-1.4.\'
import org.micromanager.MMStudio;

java.lang.System.setProperty('org.micromanager.plugin.path', 'C:\Micro-Manager-1.4\mmplugins'); 
java.lang.System.setProperty('org.micromanager.autofocus.path', 'C:\Micro-Manager-1.4\autofocus'); %mmautofocus, not autofocus
java.lang.System.setProperty('org.micromanager.beanshell.startup.script', 'C:\Micro-Manager-1.4\scripts\mm_beanshell_startup.bsh'); 
gui = MMStudio(false);
mmc = gui.getCore;
acq = gui.getAcquisitionEngine;
warning('off', 'MATLAB:javaclasspath:jarAlreadySpecified');
javaaddpath('C:\Micro-Manager-1.4\mmplugins\Device_Control\StageControl.jar');
import org.micromanager.stagecontrol.StageControl;

cd(current_directory_path)

assignin('base','backup_MMC_reference',mmc);