function handles=ini_stage_ref(handles)


% handles.delta_z_ref.String='0';
    handles.motors.port = serial('com1','BaudRate',9600);
    fopen(handles.motors.port);
    handles.motors.protocol=Zaber.Protocol.detect(handles.motors.port);
    handles.motors.sample = Zaber.BinaryDevice.initialize(handles.motors.protocol, 2);


% handles.port = serial('com4','BaudRate',9600);
% fopen(handles.port);
% handles.protocol=Zaber.Protocol.detect(handles.port);
% handles.ref_stage = Zaber.BinaryDevice.initialize(handles.protocol, 1);
% 
% handles.ref_arm_speed.Value=0;
% handles.ref_arm_speed.String=num2str(handles.ref_arm_speed.Value);