function varargout = save_zstack(varargin)
% SAVE_ZSTACK MATLAB code for save_zstack.fig
%      SAVE_ZSTACK, by itself, creates a new SAVE_ZSTACK or raises the existing
%      singleton*.
%
%      H = SAVE_ZSTACK returns the handle to a new SAVE_ZSTACK or the handle to
%      the existing singleton*.
%
%      SAVE_ZSTACK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAVE_ZSTACK.M with the given input arguments.
%
%      SAVE_ZSTACK('Property','Value',...) creates a new SAVE_ZSTACK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before save_zstack_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to save_zstack_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help save_zstack

% Last Modified by GUIDE v2.5 08-Mar-2022 17:14:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @save_zstack_OpeningFcn, ...
                   'gui_OutputFcn',  @save_zstack_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before save_zstack is made visible.
function save_zstack_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to save_zstack (see VARARGIN)

% Choose default command line output for save_zstack
handles.output = hObject;
handles.z_min_value.Value = str2double(handles.z_min_value.String);
handles.z_max_value.Value = str2double(handles.z_max_value.String);
handles.step_value.Value = str2double(handles.step_value.String);
handles.vector = [handles.z_min_value.Value:handles.step_value.Value:handles.z_max_value.Value];
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes save_zstack wait for user response (see UIRESUME)
% uiwait(handles.save_zstack);


% --- Outputs from this function are returned to the command line.
function varargout = save_zstack_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function z_min_value_Callback(hObject, eventdata, handles)
% hObject    handle to z_min_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.z_min_value.Value = str2double(handles.z_min_value.String);
handles.vector = [handles.z_min_value.Value:handles.step_value.Value:handles.z_max_value.Value];
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function z_min_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to z_min_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function z_max_value_Callback(hObject, eventdata, handles)
% hObject    handle to z_max_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.z_max_value.Value = str2double(handles.z_max_value.String);
handles.vector = [handles.z_min_value.Value:handles.step_value.Value:handles.z_max_value.Value];
% fds=handles.vector;
% fds
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function z_max_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to z_max_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function step_value_Callback(hObject, eventdata, handles)
% hObject    handle to step_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.step_value.Value = str2double(handles.step_value.String);
handles.vector = [handles.z_min_value.Value:handles.step_value.Value:handles.z_max_value.Value];
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function step_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to step_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
