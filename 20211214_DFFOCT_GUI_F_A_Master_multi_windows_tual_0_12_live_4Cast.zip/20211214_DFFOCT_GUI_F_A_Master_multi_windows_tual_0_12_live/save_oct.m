function varargout = save_oct(varargin)
% SAVE_OCT MATLAB code for save_oct.fig
%      SAVE_OCT, by itself, creates a new SAVE_OCT or raises the existing
%      singleton*.
%
%      H = SAVE_OCT returns the handle to a new SAVE_OCT or the handle to
%      the existing singleton*.
%
%      SAVE_OCT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAVE_OCT.M with the given input arguments.
%
%      SAVE_OCT('Property','Value',...) creates a new SAVE_OCT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before save_oct_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to save_oct_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help save_oct

% Last Modified by GUIDE v2.5 15-Apr-2022 14:20:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @save_oct_OpeningFcn, ...
                   'gui_OutputFcn',  @save_oct_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before save_oct is made visible.
function save_oct_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to save_oct (see VARARGIN)

% Choose default command line output for save_oct
handles.output = hObject;

% Update handles structure
master = findobj(allchild(0), 'flat', 'tag', 'gui_master_ts');   % [EDITED]
handles.master= guidata(master);

   
handles=ini_save_acq(handles);
handles=save_oct_TTL(handles);



parpool(5)

guidata(hObject, handles);

% UIWAIT makes save_oct wait for user response (see UIRESUME)
% uiwait(handles.save_oct_win);


% --- Outputs from this function are returned to the command line.
function varargout = save_oct_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function save_oct_frames_acquired_fct_C_Callback(hObject, eventdata, handles)

handles.save_oct_frames_acquired_fct_C.Value=str2double(handles.save_oct_frames_acquired_fct_C.String);

handles=stop_everything_sub(handles);

handles=save_oct_TTL(handles);
guidata(hObject, handles);

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_oct_frames_acquired_fct_C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_frames_acquired_fct_C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_frame_per_second_Callback(hObject, eventdata, handles)
handles.save_oct_frame_per_second.Value=str2double(handles.save_oct_frame_per_second.String);

handles=stop_everything_sub(handles);

handles.master.d.Rate=handles.save_oct_frame_per_second.Value*100;%?useless

tmax=(1000/handles.save_oct_frame_per_second.Value)-(10/handles.save_oct_frame_per_second.Value);


if handles.save_oct_expo_time.Value>=tmax
    handles.save_oct_expo_time.Value=tmax;
    handles.save_oct_expo_time.String=num2str(handles.save_oct_expo_time.Value);
end

handles.save_oct_duty_cycle_TTL.Value=floor(100*(handles.save_oct_expo_time.Value)/(1000/handles.save_oct_frame_per_second.Value));
handles.save_oct_duty_cycle_TTL.String=num2str(handles.save_oct_duty_cycle_TTL.Value);



handles=save_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function save_oct_frame_per_second_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_frame_per_second (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_expo_time_Callback(hObject, eventdata, handles)
handles=stop_everything_sub(handles);

f=str2double(handles.save_oct_expo_time.String);
handles.save_oct_expo_time.Value=f;

if (1000/handles.save_oct_frame_per_second.Value)<f
    handles.save_oct_frame_per_second.Value=(1000/f)-1;
    handles.save_oct_frame_per_second.String=num2str(handles.save_oct_frame_per_second.Value);
else
    handles.save_oct_frame_per_second.String=num2str(handles.save_oct_frame_per_second.Value);
end

handles.save_oct_duty_cycle_TTL.Value=floor(100*(handles.save_oct_expo_time.Value)/(1000/handles.save_oct_frame_per_second.Value));
handles.save_oct_duty_cycle_TTL.String=num2str(handles.save_oct_duty_cycle_TTL.Value);
handles=save_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function save_oct_expo_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_expo_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_accu_Callback(hObject, eventdata, handles)
handles.save_oct_accu.Value=str2double(handles.save_oct_accu.String);

handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_oct_accu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_accu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_duty_cycle_TTL_Callback(hObject, eventdata, handles)
handles=stop_everything_sub(handles);
handles.save_oct_duty_cycle_TTL.Value=str2double(handles.save_oct_duty_cycle_TTL.String);

handles=stop_everything_sub(handles);

handles.save_oct_expo_time.Value=(handles.save_oct_duty_cycle_TTL.Value/100)*(1000/handles.save_oct_frame_per_second.Value);
handles.save_oct_expo_time.String=num2str(handles.save_oct_expo_time.Value);


handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_oct_duty_cycle_TTL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_duty_cycle_TTL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in save_oct_mode.
function save_oct_mode_Callback(hObject, eventdata, handles)
handles=stop_everything_sub(handles);

if handles.save_oct_mode.Value==3
    if handles.save_oct_frames_acquired_fct_C.Value<2
    handles.save_oct_frames_acquired_fct_C.String='2';
    handles.save_oct_frames_acquired_fct_C.Value=2;
    end
    if handles.save_oct_duty_cycle_TTL.Value>50
    handles.save_oct_duty_cycle_TTL.String='50';
    save_oct_duty_cycle_TTL_Callback(hObject, eventdata, handles)
    end
    
elseif handles.save_oct_duty_cycle_TTL.Value==9
    if handles.save_oct_frames_acquired_fct_C.Value<64
    handles.save_oct_frames_acquired_fct_C.String='64';
    handles.save_oct_frames_acquired_fct_C.Value=64;
    end
end

handles=save_oct_TTL(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function save_oct_mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_oct_pushbutton.
function save_oct_pushbutton_Callback(hObject, eventdata, handles)
if get(hObject,'Value')==1
    1
    h=save_oct_check(handles);
    2
    if h==0
        3
    
    c = clock;
    dd=([handles.save_oct_path.String '\' num2str(c(1)) '_' num2str(c(2)) '_' num2str(c(3)) '_' num2str(c(4)) '_' num2str(c(5)) '_' num2str(c(6))]);
    mkdir(dd)
    handles.dd=dd;
    handles.save_oct_pushbutton.BackgroundColor=[1 0 0];
    handles.master.d.Rate=handles.save_oct_frame_per_second.Value*100;
    
    global T
    global I
    global Z % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing
    global X
    global Y
    global Fo  % used for forecasting
    
    Fo=0;
    
    T=0;
    
    if handles.save_zstack_checkbox.Value==0
        handles.flag = ones(1,1);
        
        if handles.save_mosaic_checkbox.Value==1
            handles.save_oct_mosaic = get_oct_save_mosaic;
            handles.moz_y=handles.save_oct_mosaic.mosaic_coordinate_y;
            handles.moz_x=handles.save_oct_mosaic.mosaic_coordinate_x;
        end
        
    elseif handles.save_zstack_checkbox.Value==1
        handles.save_zstack = get_save_zstack_handles;
        handles.flag = handles.save_zstack.vector;
        
        
        
        if handles.save_mosaic_checkbox.Value==1
            handles.save_oct_mosaic = get_oct_save_mosaic;
            handles.moz_y=handles.save_oct_mosaic.mosaic_coordinate_y;
            handles.moz_x=handles.save_oct_mosaic.mosaic_coordinate_x;
        end
    end
    Z = 0; % to be careful with because if there are several triggers, Z will be incremented by 1 in save_oct_processing


    if length(handles.flag)>1
        handles.microscope=get_microscope_plus_XY_stage_handles;
        handles.oct_motor_ref=get_oct_motor_ref_handles;
        handles.z_00=handles.microscope.mmc.getPosition();
    end
    
    if handles.save_mosaic_checkbox.Value==0
    handles.moz_x = ones(1,1);
    handles.moz_y = ones(1,1);
    else
        handles.Ini_xy_position=handles.microscope.mmc.getXYStageDevice();
        handles.Ini_x=handles.microscope.mmc.getXPosition();
        handles.Ini_y=handles.microscope.mmc.getYPosition();
    end
    
%     handles.mmc.setRelativeXYPosition(handles.mmc.getXYStageDevice(), 0, +handles.delta_y.Value );
% 
% handles.mmc.waitForSystem();
% handles.absolute_y.Value=handles.mmc.getYPosition();
% handles.absolute_y.String=num2str(handles.absolute_y.Value);
% handles.mmc.setXYPosition(handles.absolute_x.Value, handles.absolute_y.Value);
% handles.mmc.waitForSystem();

        for zz = 1:length(handles.flag)
            123
            tic
            zz
            Z = Z + 1;
            if zz>1
                handles.microscope.mmc.setPosition('FocusDrive',handles.microscope.mmc.getPosition()+handles.save_zstack.step_value.Value);
                handles.microscope.mmc.waitForSystem();
                
                x=-handles.save_zstack.step_value.Value.*(0.9);
                move=round(handles.oct_motor_ref.motors.sample.Units.positiontonative(x*1e-6)); % Translates the value in microns to the number of microsteps.
                handles.oct_motor_ref.motors.sample.moverelative(move);
%                 handles.absolute_z.Value=handles.microscope.mmc.getPosition();
%                 handles.absolute_z.String=num2str(handles.absolute_z.Value);
            end
            
%             disp(['microscope zshift = ' num2str(toc)])
for tt=1:1
    tt
    T=tt;
            X=0;
            for xx=1:length(handles.moz_x)
                Y=0;
                X=X+1;

                
                for yy=1:length(handles.moz_y)
                    
                    I=0;
                    Y=Y+1;
                    
                    
                    if handles.save_mosaic_checkbox.Value==1
                        %handles.microscope.mmc.setRelativeXYPosition(handles.Ini_xy_position,  handles.moz_x(1,X), handles.moz_y(1,Y));
                        
                        xi=handles.microscope.mmc.getXPosition();
                        yi=handles.microscope.mmc.getYPosition();
                        
                        Steps_towards_xf=linspace(xi,handles.Ini_x+handles.moz_x(1,X),round(abs(xi-(handles.moz_x(1,X)+handles.Ini_x)))/20);
                        if length(Steps_towards_xf)>0
                            
                        for xxx=1:length(Steps_towards_xf)
                        handles.microscope.mmc.setXYPosition(Steps_towards_xf(1,xxx),yi);
                        handles.microscope.mmc.waitForSystem();
                        end
                        end
                        
                        
                        Steps_towards_yf=linspace(yi,handles.Ini_y+handles.moz_y(1,Y),round(abs(yi-(handles.moz_y(1,Y)+handles.Ini_y)))/20);
                        if length(Steps_towards_yf)>0
                        for yyy=1:length(Steps_towards_yf)
                        handles.microscope.mmc.setXYPosition(handles.Ini_x+handles.moz_x(1,X),Steps_towards_yf(1,yyy));
                        handles.microscope.mmc.waitForSystem();
                        end
                        end
%                         
                        
                  

%                         handles.microscope.mmc.setXYPosition(handles.Ini_x+handles.moz_x(1,X),handles.Ini_y+handles.moz_y(1,Y));%check that the vector starts with 0
%                         handles.microscope.mmc.waitForSystem();
                    end
                    
                    handles.xx=xx;
                    handles.yy=yy;
                    
            handles.master.d.IsContinuous=true;
            
            handles.part=1;
            

            tot=save_Nb_frames_tot(handles)
            

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            if handles.save_oct_mode.Value==1
 
              
            set(handles.master.vid_cam_oct, 'FramesPerTrigger', tot(1,1),'TriggerRepeat',handles.save_oct_num_of_trig.Value, 'LoggingMode', 'memory');
            handles.master.vid_cam_oct.FramesAcquiredFcnCount=1000*tot(1,1);
            
            handles.master.vid_cam_oct.FramesAcquiredFcn={};
            handles.master.vid_cam_oct.ErrorFcn = {};
            
            queueOutputData(handles.master.d,handles.TTL_output_save);            
            startBackground(handles.master.d);
            pause(0.1)
            start(handles.master.vid_cam_oct)
            
            
            tic
            wait(handles.master.vid_cam_oct)
            stop(handles.master.d)
            tT2=toc
            Image=squeeze(getdata(handles.master.vid_cam_oct));%16 bit image
%             [data stamp]=getdata(handles.master.vid_cam_oct);
%                 figure(787);plot(diff(stamp))
%                 figure(595);plot((stamp))
            whos Image
            stop(handles.master.vid_cam_oct)
            save([dd '\' 'Raw' num2str(tt) '.mat'],'Image','-v7.3','-nocompression')
            

            flushdata(handles.master.vid_cam_oct)



%             waitfor(h)
            tT3=toc-tT2
             
                
                
            else
            
            
                
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if handles.save_oct_mode.Value==8
            set(handles.master.vid_cam_oct, 'FramesPerTrigger', tot(1,1),'TriggerRepeat',handles.save_oct_num_of_trig.Value, 'LoggingMode', 'memory');
            handles.master.vid_cam_oct.FramesAcquiredFcnCount=tot(1,1);
            else
                set(handles.master.vid_cam_oct, 'FramesPerTrigger', tot,'TriggerRepeat',handles.save_oct_num_of_trig.Value, 'LoggingMode', 'memory');
            
            
            if handles.save_oct_mode.Value==13 || handles.save_oct_mode.Value==14 || handles.save_oct_mode.Value==15                
                handles.master.vid_cam_oct.FramesAcquiredFcnCount=handles.save_oct_frames_acquired_fct_C.Value;                
            else
                handles.master.vid_cam_oct.FramesAcquiredFcnCount=tot;
            end
            
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            handles.master.vid_cam_oct.FramesAcquiredFcn={'save_oct_processing',handles};
            handles.master.vid_cam_oct.ErrorFcn = {'save_oct_error',handles};
            
            if handles.save_oct_mode.Value==15
                handles.BaTc=256;
                handles.ForeIm=uint16(zeros(1440,1440,handles.BaTc));
                
                handles.master.vid_cam_oct.FramesAcquiredFcn={'save_oct_forecasting',handles};
            handles.master.vid_cam_oct.ErrorFcn = {'save_oct_error',handles};

            
            
            
            end
            

            
            
            queueOutputData(handles.master.d,handles.TTL_output_save);
            flushdata(handles.master.vid_cam_oct)
            startBackground(handles.master.d);
            pause(0.1)
            
            
            
            start(handles.master.vid_cam_oct)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if handles.save_oct_mode.Value==8
                wait(handles.master.vid_cam_oct)

                stop(handles.master.d)
                pause(0.1)
%                 flush(handles.master.d)
%                 getProperties(handles.master.d)


%                 flushdata(handles.master.d)
                handles.part=2;

                 tot(1,2)

                set(handles.master.vid_cam_oct, 'FramesPerTrigger', tot(1,2),'TriggerRepeat',handles.save_oct_num_of_trig.Value, 'LoggingMode', 'memory');
            handles.master.vid_cam_oct.FramesAcquiredFcnCount=tot(1,2);
            

            
            
%             handles.master.d.IsContinuous=false;
%             pause(0.1)
            handles.master.d.IsContinuous=true;
            queueOutputData(handles.master.d,handles.TTL_output_save_2);
            flushdata(handles.master.vid_cam_oct)
            startBackground(handles.master.d);
            pause(0.1)
            
            
%             queueOutputData(handles.master.d,handles.TTL_output_save_2);

            
%             lol2=handles.TTL_output_save_2;
%                  figure(456)
%     plot(lol2(:,1))
%      hold on
%     plot(lol2(:,2))
%     0000
%             startBackground(handles.master.d);
           
            handles.master.vid_cam_oct.FramesAcquiredFcn={'save_oct_processing',handles};
            handles.master.vid_cam_oct.ErrorFcn = {'save_oct_error_processing',handles};
            flushdata(handles.master.vid_cam_oct)
            time1=datetime('now')
            start(handles.master.vid_cam_oct)
            time2=datetime('now')
            wait(handles.master.vid_cam_oct)
%             while islogging(handles.master.vid_cam_oct)
%                 pause(0.1)
%             end
            time3=datetime('now')
            stop(handles.master.d)
            stop(handles.master.vid_cam_oct) %check if post processing is done properly even if stopping the camera
            time4=datetime('now')
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
            if handles.save_oct_mode.Value==140
                
                if handles.part==1
                pp=0
                while islogging(handles.master.vid_cam_oct)
                    if rem(pp,2)==0
                    
                    handles.microscope.mmc.setProperty('TransmittedIllumination 2','Brightness', 255);
                    
                    else
                       handles.microscope.mmc.setProperty('TransmittedIllumination 2','Brightness', 0);
                    end
                    pause(0.2)
                    handles.microscope.mmc.waitForSystem();
                    pp=pp+1;

                end
                handles.microscope.mmc.setProperty('TransmittedIllumination 2','Brightness', 0);
                 wait(handles.master.vid_cam_oct)%working? Otherwise manually wait for FramesAcquiredFcnCount x FPS


                stop(handles.master.d)
                pause(60)
                end
%                 flush(handles.master.d)
%                 getProperties(handles.master.d)


%                 flushdata(handles.master.d)

            handles.part=2;
            
            
            handles.master.d.IsContinuous=true;
            queueOutputData(handles.master.d,handles.TTL_output_save);
            startBackground(handles.master.d);
            pause(0.1)
            

           
            handles.master.vid_cam_oct.FramesAcquiredFcn={'save_oct_processing',handles};
            handles.master.vid_cam_oct.ErrorFcn = {'save_oct_error_processing',handles};
            flushdata(handles.master.vid_cam_oct)

            start(handles.master.vid_cam_oct)

            wait(handles.master.vid_cam_oct)


            stop(handles.master.d)
            stop(handles.master.vid_cam_oct) %check if post processing is done properly even if stopping the camera


            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            end
            123
            time1Slice=toc
                end
            end
end
            
            

        end
        
                if handles.save_mosaic_checkbox.Value==1
                
                handles.microscope.mmc.setRelativeXYPosition(handles.Ini_xy_position,  0, 0);
                        handles.microscope.mmc.waitForSystem();
                end
                if handles.save_zstack_checkbox.Value==1
%                         handles.microscope.mmc.setPosition('FocusDrive',handles.microscope.mmc.getPosition()-length(handles.flag).*handles.save_zstack.step_value.Value);
%                 handles.microscope.mmc.waitForSystem();
%                         x=handles.save_zstack.step_value.Value.*length(handles.flag);
%                 move=round(handles.oct_motor_ref.motors.sample.Units.positiontonative(x*1e-6)); % Translates the value in microns to the number of microsteps.
%                 handles.oct_motor_ref.motors.sample.moverelative(move);
                end
                
    end
    %wait(handles.master.vid_cam_oct)
    %handles.save_oct_pushbutton.BackgroundColor=[0 1 0];
elseif get(hObject,'Value')==0
    stop(handles.master.d)
    stop(handles.master.vid_cam_oct)
    handles.save_oct_pushbutton.BackgroundColor=[0 1 0];
end



function save_oct_waste_Callback(hObject, eventdata, handles)
handles.save_oct_waste.Value=str2double(handles.save_oct_waste.String);

if handles.save_oct_waste.Value>handles.frames_acquired_fct_C_save.Value
    handles.frames_acquired_fct_C_save.Value=handles.save_oct_waste.Value;
    handles.frames_acquired_fct_C_save.String=num2str(handles.frames_acquired_fct_C_save.Value);
end

handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_oct_waste_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_waste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_binning_Callback(hObject, eventdata, handles)
handles.save_oct_binning.Value=str2double(handles.save_oct_binning.String);

handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function save_oct_binning_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_binning (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_num_of_trig_Callback(hObject, eventdata, handles)
handles.save_oct_num_of_trig.Value = str2double(save_oct_num_of_trig, 'String');


% --- Executes during object creation, after setting all properties.
function save_oct_num_of_trig_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_num_of_trig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in save_oct_format.
function save_oct_format_Callback(hObject, eventdata, handles)
% hObject    handle to save_oct_format (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns save_oct_format contents as cell array
%        contents{get(hObject,'Value')} returns selected item from save_oct_format


% --- Executes during object creation, after setting all properties.
function save_oct_format_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_format (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function save_oct_path_Callback(hObject, eventdata, handles)





% --- Executes during object creation, after setting all properties.
function save_oct_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close save_oct_win.
function save_oct_win_CloseRequestFcn(hObject, eventdata, handles)
delete(gcp('nocreate'));
delete(hObject);


% --- Executes during object deletion, before destroying properties.
function save_oct_win_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to save_oct_win (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in cd_finder.
function cd_finder_Callback(hObject, eventdata, handles)
handles.save_oct_path.String = uigetdir(handles.save_oct_path.String);


% --- Executes on button press in save_oct_display.
function save_oct_display_Callback(hObject, eventdata, handles)
% hObject    handle to save_oct_display (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of save_oct_display


% --- Executes on button press in save_zstack_checkbox.
function save_zstack_checkbox_Callback(hObject, eventdata, handles)
if handles.save_zstack_checkbox.Value==1
    figure2handle1 = findall(0,'Tag','save_zstack');
    if isempty(figure2handle1)
        save_zstack
    end
    figure2handle2 = findall(0,'Tag','oct_motor_ref');
    if isempty(figure2handle2)
        oct_motor_ref
    end
    figure2handle3 = findall(0,'Tag','microscope_plus_XY_stage');
    if isempty(figure2handle3)
        microscope_plus_XY_stage
    end
    
elseif handles.save_zstack_checkbox.Value==0
    figure2handle1 = findall(0,'Tag','save_zstack');
    if ~isempty(figure2handle1)
        close(save_zstack)
    end
    figure2handle2 = findall(0,'Tag','oct_motor_ref');
    if ~isempty(figure2handle2)
        close(oct_motor_ref)
    end
%     figure2handle3 = findall(0,'Tag','microscope_plus_XY_stage');
%     if ~isempty(figure2handle3)
%         close(microscope_plus_XY_stage)
%     end
end


% --- Executes on button press in save_mosaic_checkbox.
function save_mosaic_checkbox_Callback(hObject, eventdata, handles)



if handles.save_mosaic_checkbox.Value==1
    figure2handle1 = findall(0,'Tag','oct_save_mosaic');
    if isempty(figure2handle1)
        oct_save_mosaic
    end
    figure2handle2 = findall(0,'Tag','oct_motor_ref');
    if isempty(figure2handle2)
        oct_motor_ref
    end
    figure2handle3 = findall(0,'Tag','microscope_plus_XY_stage');
    if isempty(figure2handle3)
        microscope_plus_XY_stage
    end
    
elseif handles.save_mosaic_checkbox.Value==0
    figure2handle1 = findall(0,'Tag','oct_save_mosaic');
    if ~isempty(figure2handle1)
        close(save_zstack)
    end
%     figure2handle2 = findall(0,'Tag','oct_motor_ref');
%     if ~isempty(figure2handle2)
%         close(oct_motor_ref)
%     end
%     figure2handle3 = findall(0,'Tag','microscope_plus_XY_stage');
%     if ~isempty(figure2handle3)
%         close(microscope_plus_XY_stage)
%     end
end


% --- Executes on button press in save_multiwell_checkbox.
function save_multiwell_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to save_multiwell_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of save_multiwell_checkbox
