
H= double(zeros(1440,1440,81));
S= double(zeros(1440,1440,81));
V= double(zeros(1440,1440,81));

for ii=1:81
    ii
H(:,:,ii)=rescale(double(imread('Hsh1c.tif',ii)));
S(:,:,ii)=rescale(double(imread('Ssh1.tif',ii)));
V(:,:,ii)=rescale(double(imread('Cush1.tif',ii)));
end

%%

% I(:,:,1)=0.66.*(I(:,:,1)-min(min(I(:,:,1))))./(max(max(I(:,:,1)))-min(min(I(:,:,1))));
I(:,:,1)=abs(1-1.*0.68.*((H(:,:,1)-0)./(max(max(I(:,:,1)))-0)))-0.30;
I(:,:,2)=double(imread('skhi.jpg'));
% I(:,:,2)=1./I(:,:,2);
I(:,:,2)=1-((I(:,:,2)-min(min(I(:,:,2))))./(max(max(I(:,:,2)))-min(min(I(:,:,2)))));

I(:,:,3)=double(imread('Mhi.jpg'));

I(:,:,3)=1.0.*(I(:,:,3)-min(min(I(:,:,3))))./(max(max(I(:,:,3)))-min(min(I(:,:,3))));
%I(:,:,3)=1.2.*(I(:,:,3)-min(min(I(:,:,3))))./(max(max(I(:,:,3)))-min(min(I(:,:,3))));
% imshow(I(:,:,3))

RGB_sat = hsv2rgb(I);
imshow(RGB_sat);axis equal

%%
I(:,:,1)=rescale(double(H(:,:,1)));

I(:,:,2)=rescale(double(S(:,:,1)));
I(:,:,3)=rescale(double(V(:,:,1)),0.5,1);
RGB_sat = hsv2rgb(I);
imshow(RGB_sat);axis equal
%%
I=zeros(1440,1440,3);
HSV=zeros(1440,1440,3,81);
for n=1:81
    n
% n=26;
U1=rescale((1-double(H(:,:,n))));
% [N,edges] = histcounts(U1);
% plot(edges(1:end-1),N)

% %%
a1=0.35;
b1=0.55;
U1(U1<a1)=a1;
U1(U1>b1)=b1;

I(:,:,1)=imgaussfilt(rescale(U1,0,0.7),2);
% %%
U2=rescale(double(S(:,:,n)));
% [N,edges] = histcounts(U2);
% plot(edges(1:end-1),N)
% 
% %%
a1=0.2;
b1=0.7;
U2(U2<a1)=a1;
U2(U2>b1)=b1;

I(:,:,2)=imgaussfilt(rescale(U2),2);


U3=rescale(double(V(:,:,n)));
% [N,edges] = histcounts(U3);
% plot(edges(1:end-1),N)



a1=0.00;
b1=0.3;
U3(U3<a1)=a1;
U3(U3>b1)=b1;

I(:,:,3)=rescale(U3);

% I(:,:,3)=rescale(log10(0.3+I(:,:,3)));

HSV(:,:,:,n) = hsv2rgb(I);





end
%%




imwrite(uint8(rescale(squeeze(HSV(:,:,:,1)),0,255)),'HSVStack.tif');

for k = 2:81
    k

    imwrite(uint8(rescale(squeeze(HSV(:,:,:,k)),0,255)),'HSVStack.tif', 'writemode', 'append');
end