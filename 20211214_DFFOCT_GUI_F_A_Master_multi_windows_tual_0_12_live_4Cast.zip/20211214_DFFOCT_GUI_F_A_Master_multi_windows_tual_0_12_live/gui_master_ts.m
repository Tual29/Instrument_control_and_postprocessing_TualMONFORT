function varargout = gui_master_ts(varargin)
% GUI_MASTER_TS MATLAB code for gui_master_ts.fig
%      GUI_MASTER_TS, by itself, creates a new GUI_MASTER_TS or raises the existing
%      singleton*.
%
%      H = GUI_MASTER_TS returns the handle to a new GUI_MASTER_TS or the handle to
%      the existing singleton*.
%
%      GUI_MASTER_TS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_MASTER_TS.M with the given input arguments.
%
%      GUI_MASTER_TS('Property','Value',...) creates a new GUI_MASTER_TS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_master_ts_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_master_ts_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_master_ts

% Last Modified by GUIDE v2.5 27-Jan-2022 17:46:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_master_ts_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_master_ts_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_master_ts is made visible.
function gui_master_ts_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_master_ts (see VARARGIN)

% Choose default command line output for gui_master_ts
handles.output = hObject;

% Update handles structure

warning('off','imaq:getdata:infFramesPerTrigger')
addpath('..\');
addpath('fun\'); % Add function folder that contains all the useful things for the gui.

%global
global T%this is to track actions done from the starting of the GUI
T=0;
handles=ini_camera_oct(handles);

%ini display
handles=ini_axes(handles);

%ini TTL
handles=ini_TTL(handles);

%%Daq
handles=ini_daq(handles);
%handles=oct_TTL(handles);

% %ini mode retrieval
% handles.mode_multi_phase.String='2';
% handles.mode_multi_phase.Value=str2double(handles.mode_multi_phase.String);

%ini stack
% handles=ini_stack(handles);

%ini ref stage
%handles=ini_stage_ref(handles);

%ini microscope IX83
% handles=ini_MM_hardware_gui(handles,'Off');
% handles.step_z.String='1';
% handles.step_z.Value=str2double(handles.step_z.String);

%ini DC piezo oct tool
handles.piezo_voltage_dc.String='0';
handles.piezo_voltage_dc.Value=str2double(handles.piezo_voltage_dc.String);

guidata(hObject, handles);

% UIWAIT makes gui_master_ts wait for user response (see UIRESUME)
% uiwait(handles.gui_master_ts);


% --- Outputs from this function are returned to the command line.
function varargout = gui_master_ts_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in checkbox_live_oct.
function checkbox_live_oct_Callback(hObject, eventdata, handles)
if handles.checkbox_live_oct.Value==1
    live_oct
elseif handles.checkbox_live_oct.Value==0
    close(live_oct)
end


% --- Executes on button press in pushbutton_global_stop.
function pushbutton_global_stop_Callback(hObject, eventdata, handles)
stop(handles.vid_cam_oct);
delete(handles.vid_cam_oct)


% --- Executes on button press in checkbox_lasers.
function checkbox_lasers_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_lasers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_lasers


% --- Executes on button press in checkbox_oct_z_stack.
function checkbox_oct_z_stack_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_oct_z_stack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_oct_z_stack


% --- Executes on button press in checkbox_oct_piezo_voltage.
function checkbox_oct_piezo_voltage_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_oct_piezo_voltage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_oct_piezo_voltage



function oct_array_digi_size_Callback(hObject, eventdata, handles)
handles.oct_array_digi_size.Value=str2double(handles.oct_array_digi_size.String);

handles.vid_cam_oct.ROIPosition = ...
    [ceil((handles.res_y-handles.oct_array_digi_size.Value)./2) 0 ...
    handles.oct_array_digi_size.Value 1440];

handles=ini_axes(handles);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function oct_array_digi_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oct_array_digi_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function phase_shift_Callback(hObject, eventdata, handles)
handles=stop_everything_R(handles);
handles.phase_shift.Value=str2double(handles.phase_shift.String);

handles=live_oct_TTL(handles);
handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function phase_shift_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phase_shift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function V_c_TTL_Callback(hObject, eventdata, handles)
handles=stop_everything_R(handles);
handles.V_c_TTL.Value=str2double(handles.V_c_TTL.String);
handles=live_oct_TTL(handles);
handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function V_c_TTL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to V_c_TTL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function piezo_voltage_dc_Callback(hObject, eventdata, handles)
handles=stop_everything_R(handles);
handles.piezo_voltage_dc.Value=str2double(handles.piezo_voltage_dc.String);
handles=live_oct_TTL(handles);
handles=save_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function piezo_voltage_dc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to piezo_voltage_dc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dot_pc_TTL_Callback(hObject, eventdata, handles)
handles=stop_everything_R(handles);
handles.dot_pc_TTL.Value=str2double(handles.dot_pc_TTL.String);
handles=oct_TTL_live(handles);
handles=oct_TTL_save(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function dot_pc_TTL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dot_pc_TTL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function n_o_c_TTL_Callback(hObject, eventdata, handles)
handles=stop_everything_R(handles);
handles.n_o_c_TTL.Value=str2double(handles.n_o_c_TTL.String);
handles=live_oct_TTL(handles);
handles=save_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function n_o_c_TTL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n_o_c_TTL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_save_oct.
function checkbox_save_oct_Callback(hObject, eventdata, handles)
if handles.checkbox_save_oct.Value==1
    save_oct
elseif handles.checkbox_save_oct.Value==0
    close(save_oct)
end


% --- Executes when user attempts to close gui_master_ts.
function gui_master_ts_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to gui_master_ts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
stop(handles.vid_cam_oct);
delete(handles.vid_cam_oct);
close(win1)
close(win2)
close(win3)
close(live_oct)
% close(figure123)
delete(hObject);


% --- Executes during object deletion, before destroying properties.
function gui_master_ts_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to gui_master_ts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox_microscope.
function checkbox_microscope_Callback(hObject, eventdata, handles)
microscope_plus_XY_stage


% --- Executes on button press in ffdss.
function ffdss_Callback(hObject, eventdata, handles)
% hObject    handle to ffdss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ffdss
