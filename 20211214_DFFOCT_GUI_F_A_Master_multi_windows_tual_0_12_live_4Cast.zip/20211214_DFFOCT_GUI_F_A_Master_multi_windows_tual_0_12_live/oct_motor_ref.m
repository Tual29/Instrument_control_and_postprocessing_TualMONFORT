function varargout = oct_motor_ref(varargin)
% OCT_MOTOR_REF MATLAB code for oct_motor_ref.fig
%      OCT_MOTOR_REF, by itself, creates a new OCT_MOTOR_REF or raises the existing
%      singleton*.
%
%      H = OCT_MOTOR_REF returns the handle to a new OCT_MOTOR_REF or the handle to
%      the existing singleton*.
%
%      OCT_MOTOR_REF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OCT_MOTOR_REF.M with the given input arguments.
%
%      OCT_MOTOR_REF('Property','Value',...) creates a new OCT_MOTOR_REF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before oct_motor_ref_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to oct_motor_ref_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help oct_motor_ref

% Last Modified by GUIDE v2.5 17-Feb-2022 11:07:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @oct_motor_ref_OpeningFcn, ...
                   'gui_OutputFcn',  @oct_motor_ref_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before oct_motor_ref is made visible.
function oct_motor_ref_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to oct_motor_ref (see VARARGIN)

% Choose default command line output for oct_motor_ref
    
handles.output = hObject;

% Update handles structure

    handles.delta_z_ref.String='0';
    handles.delta_v_ref.String='0';
    handles.motors.port = serial('com3','BaudRate',9600);
    fopen(handles.motors.port);
    handles.motors.protocol=Zaber.Protocol.detect(handles.motors.port);
    handles.motors.sample = Zaber.BinaryDevice.initialize(handles.motors.protocol, 1);
%     handles.motors.ref = Zaber.BinaryDevice.initialize(handles.motors.protocol, 1);
%     handles.motors.RefMode=get(handles.menuRefMotor,'Value');
%     handles.motors.SampleMode=get(handles.menuSampleMotor,'Value');
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = oct_motor_ref_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function oct_motor_ref_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oct_motor_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in minusZ_ref.
function minusZ_ref_Callback(hObject, eventdata, handles)
x=str2double(get(handles.delta_z_ref,'String'));
move=round(handles.motors.sample.Units.positiontonative(x*1e-6)); % Translates the value in microns to the number of microsteps.
        handles.motors.sample.moverelative(-1*move);


% --- Executes on button press in plusZ_ref.
function plusZ_ref_Callback(hObject, eventdata, handles)
x=str2double(get(handles.delta_z_ref,'String'));
move=round(handles.motors.sample.Units.positiontonative(x*1e-6)); % Translates the value in microns to the number of microsteps.
        handles.motors.sample.moverelative(move);



function delta_z_ref_Callback(hObject, eventdata, handles)
% x=str2double(get(handles.delta_z_ref,'String'));
% move=round(handles.motors.sample.Units.positiontonative(x*1e-6)*2); % Translates the value in microns to the number of microsteps.
%         handles.motors.sample.moverelative(-1*move);

% --- Executes during object creation, after setting all properties.
function delta_z_ref_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_z_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_as_ref.
function save_as_ref_Callback(hObject, eventdata, handles)
curr_pos = get(handles.curr_pos_ref,'String');
set(handles.ref_pos,'String',curr_pos);



function delta_v_ref_Callback(hObject, eventdata, handles)
% hObject    handle to delta_v_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delta_v_ref as text
%        str2double(get(hObject,'String')) returns contents of delta_v_ref as a double


% --- Executes during object creation, after setting all properties.
function delta_v_ref_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_v_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in minusV_ref.
function minusV_ref_Callback(hObject, eventdata, handles)
if get(handles.minusV_ref,'Value')==1
%     set(handles.minusV_ref,'String','STOP');
    v = str2double(get(handles.delta_v_ref,'String'));
    move = round(handles.motors.sample.Units.velocitytonative(v*1e-6));
        handles.motors.sample.moveatvelocity(-1*move);
elseif get(handles.minusV_ref,'Value')==0
    handles.motors.sample.stop();
%     set(handles.minusV_ref,'String','-');
end

% Hint: get(hObject,'Value') returns toggle state of minusV_ref


% --- Executes on button press in plusV_ref.
function plusV_ref_Callback(hObject, eventdata, handles)
if get(handles.plusV_ref,'Value')==1
%     set(handles.plusV_ref,'String','STOP');
    v = str2double(get(handles.delta_v_ref,'String'));
    move = round(handles.motors.sample.Units.velocitytonative(v*1e-6));
        handles.motors.sample.moveatvelocity(move);
elseif get(handles.plusV_ref,'Value')==0
    handles.motors.sample.stop();
%     set(handles.plusV_ref,'String','+');
end

% Hint: get(hObject,'Value') returns toggle state of plusV_ref


% --- Executes on button press in read_pos.
function read_pos_Callback(hObject, eventdata, handles)
position = num2str(handles.motors.sample.getposition());
set(handles.curr_pos_ref,'String',position);


% --- Executes on button press in go_to_ref.
function go_to_ref_Callback(hObject, eventdata, handles)
ref_pos = str2double(get(handles.ref_pos,'String'));
handles.motors.sample.moveabsolute(ref_pos);


% --- Executes when user attempts to close oct_motor_ref.
function oct_motor_ref_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to oct_motor_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fclose(handles.motors.port);
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes during object creation, after setting all properties.
function curr_pos_ref_CreateFcn(hObject, eventdata, handles)
% hObject    handle to curr_pos_ref (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
