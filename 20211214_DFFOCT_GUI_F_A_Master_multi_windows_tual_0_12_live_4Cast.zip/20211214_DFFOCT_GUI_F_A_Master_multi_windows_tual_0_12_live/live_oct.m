function varargout = live_oct(varargin)
% LIVE_OCT_PANEL MATLAB code for live_oct_panel.fig
%      LIVE_OCT_PANEL, by itself, creates a new LIVE_OCT_PANEL or raises the existing
%      singleton*.
%
%      H = LIVE_OCT_PANEL returns the handle to a new LIVE_OCT_PANEL or the handle to
%      the existing singleton*.
%
%      LIVE_OCT_PANEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LIVE_OCT_PANEL.M with the given input arguments.
%
%      LIVE_OCT_PANEL('Property','Value',...) creates a new LIVE_OCT_PANEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before live_oct_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to live_oct_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help live_oct_panel

% Last Modified by GUIDE v2.5 26-Sep-2022 12:59:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @live_oct_OpeningFcn, ...
                   'gui_OutputFcn',  @live_oct_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before live_oct_panel is made visible.
function live_oct_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to live_oct_panel (see VARARGIN)

% Choose default command line output for live_oct_panel
handles.output = hObject;

% Update handles structure

master = findobj(allchild(0), 'flat', 'tag', 'gui_master_ts');   % [EDITED]
handles.master= guidata(master);

% set(handles.master.gui1Handles.one, 'CData', 1000*rand(1440,1440))

% gui_one = findobj(allchild(0), 'flat', 'tag', 'win1');   % [EDITED]
% handles.gui1Handles = guidata(gui_one);
% set(handles.gui1Handles.one, 'CData', 1000*rand(1440,1440))
%     
handles=ini_live_acq(handles);
handles=live_oct_TTL(handles);

guidata(hObject, handles);

% UIWAIT makes live_oct_panel wait for user response (see UIRESUME)
% uiwait(handles.live_oct_win);


% --- Outputs from this function are returned to the command line.
function varargout = live_oct_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function live_oct_frames_acquired_fct_C_Callback(hObject, eventdata, handles)

handles.live_oct_frames_acquired_fct_C.Value=str2double(handles.live_oct_frames_acquired_fct_C.String);
if rem(handles.live_oct_frames_acquired_fct_C.Value,2)==0
    handles.frames_acquired_2phase=handles.live_oct_frames_acquired_fct_C.Value;
else
    handles.frames_acquired_2phase=handles.live_oct_frames_acquired_fct_C.Value-1;
end
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function live_oct_frames_acquired_fct_C_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_frames_acquired_fct_C (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_frame_per_second_Callback(hObject, eventdata, handles)

handles.live_oct_frame_per_second.Value=str2double(handles.live_oct_frame_per_second.String);

handles=stop_everything_sub(handles);

handles.master.d.Rate=handles.live_oct_frame_per_second.Value*100;

tmax=(1000/handles.live_oct_frame_per_second.Value)-(10/handles.live_oct_frame_per_second.Value);


if handles.live_oct_expo_time.Value>=tmax
    handles.live_oct_expo_time.Value=tmax;
    handles.live_oct_expo_time.String=num2str(handles.live_oct_expo_time.Value);
end

handles.live_oct_duty_cycle_TTL.Value=floor(100*(handles.live_oct_expo_time.Value)/(1000/handles.live_oct_frame_per_second.Value));
handles.live_oct_duty_cycle_TTL.String=num2str(handles.live_oct_duty_cycle_TTL.Value);

handles=stop_everything_sub(handles);

handles=live_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function live_oct_frame_per_second_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_frame_per_second (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_expo_time_Callback(hObject, eventdata, handles)
handles=stop_everything_sub(handles);

f=str2double(handles.live_oct_expo_time.String);
handles.live_oct_expo_time.Value=f;

if (1000/handles.live_oct_frame_per_second.Value)<f
    handles.live_oct_frame_per_second.Value=(1000/f)-1;
    handles.live_oct_frame_per_second.String=num2str(handles.live_oct_frame_per_second.Value);
else
    handles.live_oct_frame_per_second.String=num2str(handles.live_oct_frame_per_second.Value);
end

handles.live_oct_duty_cycle_TTL.Value=floor(100*(handles.live_oct_expo_time.Value)/(1000/handles.live_oct_frame_per_second.Value));
handles.live_oct_duty_cycle_TTL.String=num2str(handles.live_oct_duty_cycle_TTL.Value);
handles=live_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function live_oct_expo_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_expo_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_accu_Callback(hObject, eventdata, handles)
handles.live_oct_accu.Value=str2double(handles.live_oct_accu.String);

handles=live_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function live_oct_accu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_accu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_duty_cycle_TTL_Callback(hObject, eventdata, handles)

handles=stop_everything_sub(handles);
handles.live_oct_duty_cycle_TTL.Value=str2double(handles.live_oct_duty_cycle_TTL.String);

handles=stop_everything_sub(handles);

handles.live_oct_expo_time.Value=(handles.live_oct_duty_cycle_TTL.Value/100)*(1000/handles.live_oct_frame_per_second.Value);
handles.live_oct_expo_time.String=num2str(handles.live_oct_expo_time.Value);


handles=live_oct_TTL(handles);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function live_oct_duty_cycle_TTL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_duty_cycle_TTL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in live_oct_mode.
function live_oct_mode_Callback(hObject, eventdata, handles)
handles=stop_everything_sub(handles);

if handles.live_oct_mode.Value==3
    if handles.live_oct_frames_acquired_fct_C.Value<2
    handles.live_oct_frames_acquired_fct_C.String='2';
    handles.live_oct_frames_acquired_fct_C.Value=2;
    end
    if handles.live_oct_duty_cycle_TTL.Value>50
    handles.live_oct_duty_cycle_TTL.String='50';
    live_oct_duty_cycle_TTL_Callback(hObject, eventdata, handles)
    end
    
elseif handles.live_oct_duty_cycle_TTL.Value==9
    if handles.live_oct_frames_acquired_fct_C.Value<64
    handles.live_oct_frames_acquired_fct_C.String='64';
    handles.live_oct_frames_acquired_fct_C.Value=64;
    end
end

handles=live_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function live_oct_mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in live_oct_pushbutton.
function live_oct_pushbutton_Callback(hObject, eventdata, handles)


if get(hObject,'Value')==1
%     h=live_oct_check(handles);
h=0;
    if h==0
    handles.live_oct_pushbutton.BackgroundColor=[1 0 0];
    
    handles.master.d.Rate=handles.live_oct_frame_per_second.Value*100;
    
    queueOutputData(handles.master.d,handles.TTL_output_live);
    startBackground(handles.master.d);
    pause(0.1)
   

    set(handles.master.vid_cam_oct, 'FramesPerTrigger', Inf, 'LoggingMode', 'memory');
  
    handles.master.vid_cam_oct.FramesAcquiredFcnCount=handles.live_oct_frames_acquired_fct_C.Value*handles.live_oct_binning.Value;
    

    handles.master.vid_cam_oct.FramesAcquiredFcn={'live_display',handles};
    handles.master.vid_cam_oct.ErrorFcn = {'error_live_display',handles};
    flushdata(handles.master.vid_cam_oct)
    start(handles.master.vid_cam_oct)
    end
elseif get(hObject,'Value')==0
    stop(handles.master.d)
    stop(handles.master.vid_cam_oct)
    handles.live_oct_pushbutton.BackgroundColor=[0 1 0];
end



function live_oct_waste_Callback(hObject, eventdata, handles)
handles.live_oct_waste.Value=str2double(handles.live_oct_waste.String);

if handles.live_oct_waste.Value>handles.frames_acquired_fct_C_save.Value
    handles.frames_acquired_fct_C_save.Value=handles.live_oct_waste.Value;
    handles.frames_acquired_fct_C_save.String=num2str(handles.frames_acquired_fct_C_save.Value);
end

handles=live_oct_TTL(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function live_oct_waste_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_waste (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_binning_Callback(hObject, eventdata, handles)
handles.live_oct_binning.Value=str2double(handles.live_oct_binning.String);

handles=live_oct_TTL(handles);

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function live_oct_binning_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_binning (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function live_oct_z0_Callback(hObject, eventdata, handles)
% hObject    handle to live_oct_z0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of live_oct_z0 as text
%        str2double(get(hObject,'String')) returns contents of live_oct_z0 as a double


% --- Executes during object creation, after setting all properties.
function live_oct_z0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_z0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in live_oct_lock_z0.
function live_oct_lock_z0_Callback(hObject, eventdata, handles)
% hObject    handle to live_oct_lock_z0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of live_oct_lock_z0


% --- Executes on button press in live_oct_go_to_z0.
function live_oct_go_to_z0_Callback(hObject, eventdata, handles)
% hObject    handle to live_oct_go_to_z0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit37_Callback(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit37 as text
%        str2double(get(hObject,'String')) returns contents of edit37 as a double


% --- Executes during object creation, after setting all properties.
function edit37_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function live_oct_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to live_oct_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
